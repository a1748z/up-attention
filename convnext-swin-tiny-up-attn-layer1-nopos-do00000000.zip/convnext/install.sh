pip install timm
pip install rich
pip install tensorboardX
pip install einops
pip install deepspeed
pip install yacs