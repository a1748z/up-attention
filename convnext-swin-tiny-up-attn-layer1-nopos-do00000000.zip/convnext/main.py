# Copyright (c) Meta Platforms, Inc. and affiliates.

# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.


import argparse
import datetime
import numpy as np
import time
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.optim import lr_scheduler
import json
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7,8"  # 9,10,11,12,13  0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15
from pathlib import Path

from timm.data.mixup import Mixup
from timm.models import create_model
from timm.loss import LabelSmoothingCrossEntropy, SoftTargetCrossEntropy
from timm.utils import ModelEma

from datasets import build_dataset
from utils import NativeScalerWithGradNormCount as NativeScaler
import utils
import models.convnext
import models.convnext_isotropic
import models.vit
import models.swin

from engine_v3 import train_one_epoch, evaluate
from optim_factory_v3 import create_optimizer, LayerDecayValueAssigner
# from engine_v3 import train_one_epoch, evaluate
# from optim_factory_v3 import create_optimizer, LayerDecayValueAssigner

from opts import get_args_parser
# from rich import print
from util_scripts.print_info import pre_print, running_print, st1, _st1, get_lr, get_fine_tuning_parameters, get_fine_tuning_lr

def main(args):
    utils.init_distributed_mode(args)
    pre_print("\n{}args:{}\n{}\n".format(st1, _st1, args))

    print("PyTorch version: {}".format(torch.__version__))                    # PyTorch version
    print("CUDA is available: {}".format(torch.cuda.is_available()))          # check if CUDA is available
    if torch.cuda.is_available():
        print("CUDA version: {}".format(torch.version.cuda))                  # CUDA version
        print("cuDNN version: {}".format(torch.backends.cudnn.version()))     # cuDNN version
        print("CUDA device name: {}".format(torch.cuda.get_device_name()))    # GPU type

    device = torch.device(args.device)

    # fix the seed for reproducibility
    seed = args.seed + utils.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)
    cudnn.benchmark = True

    dataset_train, args.nb_classes = build_dataset(is_train=True, args=args)
    if args.disable_eval:
        args.dist_eval = False
        dataset_val = None
    else:
        dataset_val, _ = build_dataset(is_train=False, args=args)

    num_tasks = utils.get_world_size()
    global_rank = utils.get_rank()

    sampler_train = torch.utils.data.DistributedSampler(
        dataset_train, num_replicas=num_tasks, rank=global_rank, shuffle=True, seed=args.seed,
    )
    print("Sampler_train = %s" % str(sampler_train))
    if args.dist_eval:
        if len(dataset_val) % num_tasks != 0:
            print('Warning: Enabling distributed evaluation with an eval dataset not divisible by process number. '
                    'This will slightly alter validation results as extra duplicate entries are added to achieve '
                    'equal num of samples per-process.')
        sampler_val = torch.utils.data.DistributedSampler(
            dataset_val, num_replicas=num_tasks, rank=global_rank, shuffle=False)
    else:
        sampler_val = torch.utils.data.SequentialSampler(dataset_val)

    if global_rank == 0 and args.log_dir is not None:
        os.makedirs(args.log_dir, exist_ok=True)
        log_writer = utils.TensorboardLogger(log_dir=args.log_dir)
    else:
        log_writer = None

    if global_rank == 0 and args.enable_wandb:
        wandb_logger = utils.WandbLogger(args)
    else:
        wandb_logger = None

    data_loader_train = torch.utils.data.DataLoader(
        dataset_train, sampler=sampler_train,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        pin_memory=args.pin_mem,
        drop_last=True,
    )

    if dataset_val is not None:
        data_loader_val = torch.utils.data.DataLoader(
            dataset_val, sampler=sampler_val,
            batch_size=int(1.5 * args.batch_size),
            num_workers=args.num_workers,
            pin_memory=args.pin_mem,
            drop_last=False
        )
    else:
        data_loader_val = None

    mixup_fn = None
    mixup_active = args.mixup > 0 or args.cutmix > 0. or args.cutmix_minmax is not None
    if mixup_active:
        print("Mixup is activated!")
        mixup_fn = Mixup(
            mixup_alpha=args.mixup, cutmix_alpha=args.cutmix, cutmix_minmax=args.cutmix_minmax,
            prob=args.mixup_prob, switch_prob=args.mixup_switch_prob, mode=args.mixup_mode,
            label_smoothing=args.smoothing, num_classes=args.nb_classes)

    if args.model in ['convnext_tiny', 'convnext_small', 'convnext_base', 'convnext_large', 'convnext_xlarge']:
        model = create_model(    # *----------------------------------------------------------------------------------------------------------
            args.model, 
            pretrained=False, 
            num_classes=args.nb_classes, 
            drop_path_rate=args.drop_path,
            layer_scale_init_value=args.layer_scale_init_value,
            head_init_scale=args.head_init_scale,
            )
    elif args.model in ['vit_tiny', 'vit_small', 'vit_base', 'vit_large', 'vit_xlarge']:
        model = create_model(    # *----------------------------------------------------------------------------------------------------------
            args.model, 
            pretrained=False, 
            num_classes=args.nb_classes
            )
    elif args.model in ['swin_tiny', 'swin_small', 'swin_base', 'swin_large', 'swin_xlarge']:
        model = create_model(    # *----------------------------------------------------------------------------------------------------------
            args.model, 
            pretrained=False, 
            num_classes=args.nb_classes
            )
    else:
        model = create_model(    # *----------------------------------------------------------------------------------------------------------
            args.model, 
            pretrained=False, 
            num_classes=args.nb_classes,
            drop_path_rate=args.drop_path,
            )

    if args.finetune:    # *--------------------------------------------------------------------------------------------------------------
        if args.finetune.startswith('https'):
            checkpoint = torch.hub.load_state_dict_from_url(
                args.finetune, map_location='cpu', check_hash=True)
        else:
            checkpoint = torch.load(args.finetune, map_location='cpu')

        print("Load ckpt from %s" % args.finetune)
        checkpoint_model = None
        for model_key in args.model_key.split('|'):
            if model_key in checkpoint:
                checkpoint_model = checkpoint[model_key]
                print("Load state_dict by model_key = %s" % model_key)
                break
        if checkpoint_model is None:
            checkpoint_model = checkpoint
        state_dict = model.state_dict()
        for k in ['head.weight', 'head.bias']:
            if k in checkpoint_model and checkpoint_model[k].shape != state_dict[k].shape:
                print(f"Removing key {k} from pretrained checkpoint")
                del checkpoint_model[k]
        utils.load_state_dict(model, checkpoint_model, prefix=args.model_prefix)
        pre_print("{}fintuen model was loaded.{}", (st1, _st1))
    model.to(device)

    model_ema = None
    if args.model_ema:
        # Important to create EMA model after cuda(), DP wrapper, and AMP but before SyncBN and DDP wrapper
        model_ema = ModelEma(
            model,
            decay=args.model_ema_decay,
            device='cpu' if args.model_ema_force_cpu else '',
            resume='')
        print("Using EMA with decay = %.8f" % args.model_ema_decay)

    model_without_ddp = model
    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)

    print("Model = %s" % str(model_without_ddp))
    print('number of params:', n_parameters)

    total_batch_size = args.batch_size * args.update_freq * utils.get_world_size()
    num_training_steps_per_epoch = len(dataset_train) // total_batch_size
    print("LR = %.8f" % args.lr)
    print("Batch size = %d" % total_batch_size)
    print("Update frequent = %d" % args.update_freq)
    print("Number of training examples = %d" % len(dataset_train))
    print("Number of training training per epoch = %d" % num_training_steps_per_epoch)

    if args.layer_decay < 1.0 or args.layer_decay > 1.0:
        num_layers = 12 # convnext layers divided into 12 parts, each with a different decayed lr value.
        assert args.model in ['convnext_small', 'convnext_base', 'convnext_large', 'convnext_xlarge', \
                              'vit_tiny', 'vit_small', 'vit_base', 'vit_large', 'vit_xlarge'], \
             "Layer Decay impl only supports convnext_small/base/large/xlarge"
        assigner = LayerDecayValueAssigner(list(args.layer_decay ** (num_layers + 1 - i) for i in range(num_layers + 2)))
    else:
        assigner = None

    if assigner is not None:
        print("Assigned values = %s" % str(assigner.values))

    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu], find_unused_parameters=False)
        model_without_ddp = model.module

    optimizer = create_optimizer(
        args, model_without_ddp, skip_list=None,
        get_num_layer=assigner.get_layer_id if assigner is not None else None, 
        get_layer_scale=assigner.get_scale if assigner is not None else None,
        get_ft_params=get_fine_tuning_parameters,
        get_fine_tuning_lr=get_fine_tuning_lr)

    loss_scaler = NativeScaler() # if args.use_amp is False, this won't be used

    assert args.lr_scheduler in ['plateau', 'multistep', 'cyclic']
    # assert not (args.lr_scheduler == 'plateau' and args.no_val)
    if args.lr_scheduler == 'plateau':
        print("\nusing plateau: patience is {}\n".format(args.plateau_patience))
        # factor default: 0.1
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=args.plateau_patience, factor=0.5, verbose=True)
        lr_schedule_values=None
        ft_lr_schedule_values=None
        wd_schedule_values=None
    elif args.lr_scheduler == 'multistep':
        print("\nusing multisteps: {}\n".format(args.multistep_milestones))
        scheduler = lr_scheduler.MultiStepLR(optimizer, args.multistep_milestones, gamma=0.5)
        lr_schedule_values=None
        ft_lr_schedule_values=None
        wd_schedule_values=None
    else:
        print("Use Cosine LR scheduler")
        lr_schedule_values = utils.cosine_scheduler(args.lr, args.min_lr, args.epochs, num_training_steps_per_epoch,
                                                    warmup_epochs=args.warmup_epochs, warmup_steps=args.warmup_steps,)
        if args.finetune and args.attention_lr is not None:
            ft_lr_schedule_values = utils.cosine_scheduler(args.attention_lr, args.min_lr, args.epochs, num_training_steps_per_epoch,
                                                        warmup_epochs=args.warmup_epochs, warmup_steps=args.warmup_steps,)
        else:
            ft_lr_schedule_values = None
        print(lr_schedule_values)
        print(ft_lr_schedule_values)

        if args.weight_decay_end is None:
            args.weight_decay_end = args.weight_decay
        wd_schedule_values = utils.cosine_scheduler(args.weight_decay, args.weight_decay_end, args.epochs, num_training_steps_per_epoch)
        print("Max WD = %.7f, Min WD = %.7f" % (max(wd_schedule_values), min(wd_schedule_values)))

        scheduler = None

    if mixup_fn is not None:
        # smoothing is handled with mixup label transform
        criterion = SoftTargetCrossEntropy()
    elif args.smoothing > 0.:
        criterion = LabelSmoothingCrossEntropy(smoothing=args.smoothing)
    else:
        criterion = torch.nn.CrossEntropyLoss()

    print("criterion = %s" % str(criterion))

    utils.auto_load_model(
        args=args, model=model, model_without_ddp=model_without_ddp,
        optimizer=optimizer, loss_scaler=loss_scaler, model_ema=model_ema)

    if args.eval:
        print(f"Eval only mode")
        test_stats, _ = evaluate(data_loader_val, model, device, use_amp=args.use_amp)
        print(f"Accuracy of the network on {len(dataset_val)} test images: {test_stats['acc1']:.5f}%")
        return

    max_accuracy = 0.0
    if args.model_ema and args.model_ema_eval:
        max_accuracy_ema = 0.0

    print("Start training for %d epochs" % args.epochs)
    start_time = time.time()
    prev_val_loss = None
    prev_val_loss_ema = None
    for epoch in range(args.start_epoch, args.epochs):    # *-----------------------------------------------------------------------------
        if args.distributed:
            data_loader_train.sampler.set_epoch(epoch)
        if log_writer is not None:
            log_writer.set_step(epoch * num_training_steps_per_epoch * args.update_freq)
        if wandb_logger:
            wandb_logger.set_steps()

        # *-------------------------------------------------------------------------------------------------------------------------------
        current_lr = get_lr(optimizer)
        pre_print("{}current lr:{} {}", (st1, _st1, current_lr))
        # exit()
        train_stats = train_one_epoch(
            model, criterion, data_loader_train, optimizer,
            device, epoch, loss_scaler, args.clip_grad, model_ema, mixup_fn,
            log_writer=log_writer, wandb_logger=wandb_logger, start_steps=epoch * num_training_steps_per_epoch,
            lr_schedule_values=lr_schedule_values, ft_lr_schedule_values=ft_lr_schedule_values, wd_schedule_values=wd_schedule_values,
            num_training_steps_per_epoch=num_training_steps_per_epoch, update_freq=args.update_freq,
            use_amp=args.use_amp
        )

        if args.output_dir and args.save_ckpt:
            if (epoch + 1) % args.save_ckpt_freq == 0 or epoch + 1 == args.epochs:
                utils.save_model(args=args, model=model, model_without_ddp=model_without_ddp, optimizer=optimizer,
                                 loss_scaler=loss_scaler, epoch=epoch, model_ema=model_ema, scheduler=scheduler)
        if data_loader_val is not None:
            test_stats, prev_val_loss = evaluate(data_loader_val, model, device, use_amp=args.use_amp)
            print(f"Accuracy of the model on the {len(dataset_val)} test images at Epoch {epoch + 1}: {test_stats['acc1']:.3f}%")
            if max_accuracy < test_stats["acc1"]:
                max_accuracy = test_stats["acc1"]
                if args.output_dir and args.save_ckpt:
                    utils.save_model(args=args, model=model, model_without_ddp=model_without_ddp, optimizer=optimizer,
                                     loss_scaler=loss_scaler, epoch="best", model_ema=model_ema, scheduler=scheduler)
            print(f'Max accuracy: {max_accuracy:.2f}%')

            if log_writer is not None:
                log_writer.update(test_acc1=test_stats['acc1'], head="perf", step=epoch)
                log_writer.update(test_acc5=test_stats['acc5'], head="perf", step=epoch)
                log_writer.update(test_loss=test_stats['loss'], head="perf", step=epoch)

            log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                         **{f'test_{k}': v for k, v in test_stats.items()},
                         'epoch': epoch,
                         'n_parameters': n_parameters}

            # repeat testing routines for EMA, if ema eval is turned on
            if args.model_ema and args.model_ema_eval:
                test_stats_ema, prev_val_loss_ema = evaluate(data_loader_val, model_ema.ema, device, use_amp=args.use_amp)
                print(f"Accuracy of the model EMA on {len(dataset_val)} test images at Epoch {epoch + 1}: {test_stats_ema['acc1']:.3f}%")
                if max_accuracy_ema < test_stats_ema["acc1"]:
                    max_accuracy_ema = test_stats_ema["acc1"]
                    if args.output_dir and args.save_ckpt:
                        utils.save_model(args=args, model=model, model_without_ddp=model_without_ddp, optimizer=optimizer,
                                         loss_scaler=loss_scaler, epoch="best-ema", model_ema=model_ema, scheduler=scheduler)
                    print(f'Max EMA accuracy: {max_accuracy_ema:.2f}%')
                if log_writer is not None:
                    log_writer.update(test_acc1_ema=test_stats_ema['acc1'], head="perf", step=epoch)
                log_stats.update({**{f'test_{k}_ema': v for k, v in test_stats_ema.items()}})

            if args.lr_scheduler == 'multistep':
                scheduler.step()
            elif args.lr_scheduler == 'plateau' and prev_val_loss is not None and prev_val_loss_ema is not None:
                scheduler.step(prev_val_loss)      # *scheduler.step(prev_val_loss_ema)
        else:
            log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                         'epoch': epoch,
                         'n_parameters': n_parameters}

            if args.lr_scheduler == 'plateau':
                print("plateau lr scheduler need model evaluation!")
                exit()
            elif args.lr_scheduler == 'multistep':
                scheduler.step()

        if args.output_dir and utils.is_main_process():
            if log_writer is not None:
                log_writer.flush()
            with open(os.path.join(args.output_dir, "log.txt"), mode="a", encoding="utf-8") as f:
                f.write(json.dumps(log_stats) + "\n")

        if wandb_logger:
            wandb_logger.log_epoch_metrics(log_stats)

    if wandb_logger and args.wandb_ckpt and args.save_ckpt and args.output_dir:
        wandb_logger.log_checkpoints()


    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print('Training time {}'.format(total_time_str))

if __name__ == '__main__':
    parser = argparse.ArgumentParser('ConvNeXt training and evaluation script', parents=[get_args_parser()])
    args = parser.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    main(args)

'''
Weights of ConvNeXt not initialized from pretrained model:
[
    'stages.2.0.conv_up2.weight',
    'stages.2.0.bn_up2.weight',
    'stages.2.0.bn_up2.bias',
    'stages.2.0.bn_up2.running_mean',
    'stages.2.0.bn_up2.running_var',
    'stages.2.0.up_attention_up2.0.cls_token',
    'stages.2.0.up_attention_up2.0.pos_emb.weight',
    'stages.2.0.up_attention_up2.0.pos_query.weight',
    'stages.2.0.up_attention_up2.0.layer.0.0.fn.to_q.weight',
    'stages.2.0.up_attention_up2.0.layer.0.0.fn.to_kv1.weight',
    'stages.2.0.up_attention_up2.0.layer.0.0.fn.to_out.0.weight',
    'stages.2.0.up_attention_up2.0.layer.0.0.fn.to_out.0.bias',
    'stages.2.0.up_attention_up2.0.layer.0.0.norm1.weight',
    'stages.2.0.up_attention_up2.0.layer.0.0.norm1.bias',
    'stages.2.0.up_attention_up2.0.layer.0.0.norm2.weight',
    'stages.2.0.up_attention_up2.0.layer.0.0.norm2.bias',
    'stages.2.0.up_attention_up2.0.layer.0.1.fn.net.0.weight',
    'stages.2.0.up_attention_up2.0.layer.0.1.fn.net.0.bias',
    'stages.2.0.up_attention_up2.0.layer.0.1.fn.net.3.weight',
    'stages.2.0.up_attention_up2.0.layer.0.1.fn.net.3.bias',
    'stages.2.0.up_attention_up2.0.layer.0.1.norm.weight',
    'stages.2.0.up_attention_up2.0.layer.0.1.norm.bias',
    'stages.2.0.up_attention_up2.0.to_out.weight',
    'stages.2.0.up_attention_up2.0.to_out.bias',
    'stages.2.2.conv_up2.weight',
    'stages.2.2.bn_up2.weight',
    'stages.2.2.bn_up2.bias',
    'stages.2.2.bn_up2.running_mean',
    'stages.2.2.bn_up2.running_var',
    'stages.2.2.up_attention_up2.0.cls_token',
    'stages.2.2.up_attention_up2.0.pos_emb.weight',
    'stages.2.2.up_attention_up2.0.pos_query.weight',
    'stages.2.2.up_attention_up2.0.layer.0.0.fn.to_q.weight',
    'stages.2.2.up_attention_up2.0.layer.0.0.fn.to_kv1.weight',
    'stages.2.2.up_attention_up2.0.layer.0.0.fn.to_out.0.weight',
    'stages.2.2.up_attention_up2.0.layer.0.0.fn.to_out.0.bias',
    'stages.2.2.up_attention_up2.0.layer.0.0.norm1.weight',
    'stages.2.2.up_attention_up2.0.layer.0.0.norm1.bias',
    'stages.2.2.up_attention_up2.0.layer.0.0.norm2.weight',
    'stages.2.2.up_attention_up2.0.layer.0.0.norm2.bias',
    'stages.2.2.up_attention_up2.0.layer.0.1.fn.net.0.weight',
    'stages.2.2.up_attention_up2.0.layer.0.1.fn.net.0.bias',
    'stages.2.2.up_attention_up2.0.layer.0.1.fn.net.3.weight',
    'stages.2.2.up_attention_up2.0.layer.0.1.fn.net.3.bias',
    'stages.2.2.up_attention_up2.0.layer.0.1.norm.weight',
    'stages.2.2.up_attention_up2.0.layer.0.1.norm.bias',
    'stages.2.2.up_attention_up2.0.to_out.weight',
    'stages.2.2.up_attention_up2.0.to_out.bias',
    'head.weight',
    'head.bias'
]
'''
