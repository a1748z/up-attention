import torch
from torch import nn, einsum
import torch.nn.functional as F
from einops import rearrange, repeat
from util_scripts.print_info import running_print, st1, _st1

def conv1x3x3(in_planes, mid_planes, stride=1):
    return nn.Conv3d(in_planes,
                     mid_planes,
                     kernel_size=(1, 3, 3),
                     stride=(1, stride, stride),
                     padding=(0, 1, 1),
                     bias=False)

def conv3x1x1(mid_planes, planes, stride=1):
    return nn.Conv3d(mid_planes,
                     planes,
                     kernel_size=(3, 1, 1),
                     stride=(stride, 1, 1),
                     padding=(1, 0, 0),
                     bias=False)

def conv1x1x1(in_planes, out_planes, stride=1):
    return nn.Conv3d(in_planes,
                     out_planes,
                     kernel_size=1,
                     stride=stride,
                     bias=False)

def conv3x3x3(in_planes, out_planes, stride=1):
    return nn.Conv3d(in_planes,
                     out_planes,
                     kernel_size=(3, 3, 3),
                     stride=(stride, stride, stride),
                     padding=(1, 1, 1),
                     bias=False)

# classes

class PreNorm(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.fn = fn
        self.norm = nn.LayerNorm(dim)

    def forward(self, x, *args, **kwargs):
        x = self.norm(x)
        return self.fn(x, *args, **kwargs)

# feedforward

class GEGLU(nn.Module):
    def forward(self, x):
        x, gates = x.chunk(2, dim=-1)
        return x * F.gelu(gates)

class FeedForward(nn.Module):
    def __init__(self, dim, mult=4, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, dim * mult * 2),
            GEGLU(),
            nn.Dropout(dropout),
            nn.Linear(dim * mult, dim)
        )

    def forward(self, x):
        return self.net(x)

# attention

def attn(q, k, v):
    sim = einsum('b i d, b j d -> b i j', q, k)
    attn = sim.softmax(dim=-1)
    out = einsum('b i j, b j d -> b i d', attn, v)
    return out

class Attention(nn.Module):
    def __init__(
        self,
        dim,
        dim_head=64,
        heads=8,
        dropout=0.
    ):
        super().__init__()
        self.dim = dim
        self.heads = heads
        self.dim_head = dim_head
        self.scale = dim_head ** -0.5
        inner_dim = dim_head * heads

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias=False)
        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        h = self.heads
        running_print("{}|TimeSformer - Attention - dim-heads-dim_head:{}\t\t{}-{}-{}",
                      (st1, _st1, self.dim, self.heads, self.dim_head))
        q, k, v = self.to_qkv(x).chunk(3, dim=-1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> (b h) n d', h=h), (q, k, v))
        running_print("{}|TimeSformer - Attention - q-k-v:{}\t\t\t{}-{}-{}",
                      (st1, _st1, list(q.size()), list(k.size()), list(v.size())))

        q *= self.scale

        # splice out classification token at index 1
        (cls_q, q_), (cls_k, k_), (cls_v, v_) = map(lambda t: (t[:, 0:1], t[:, 1:]), (q, k, v))

        # let classification token attend to key / values of all patches across time and space
        cls_out = attn(cls_q, k, v)

        # expand cls token keys and values across time or space and concat
        r = q_.shape[0] // cls_k.shape[0]
        cls_k, cls_v = map(lambda t: repeat(t, 'b () d -> (b r) () d', r=r), (cls_k, cls_v))

        k_ = torch.cat((cls_k, k_), dim=1)
        v_ = torch.cat((cls_v, v_), dim=1)

        # attention
        out = attn(q_, k_, v_)

        # concat back the cls token
        out = torch.cat((cls_out, out), dim=1)

        # merge back the heads
        out = rearrange(out, '(b h) n d -> b n (h d)', h=h)

        # combine heads out
        return self.to_out(out)


# main classes
class TimeSformer(nn.Module):
    def __init__(self,
                 *,
                 dim,
                 image_size=224,
                 patch_size=1,
                 depth=12,
                 heads=8,
                 dim_head=64,
                 attn_dropout=0.,
                 ff_dropout=0.
                 ):
        super().__init__()
        assert image_size % patch_size == 0, 'Image dimensions must be divisible by the patch size.'

        num_positions = (image_size // patch_size) ** 2

        self.patch_size = patch_size
        self.pos_emb = nn.Embedding(num_positions + 1, dim)
        self.cls_token = nn.Parameter(torch.randn(1, dim))

        self.dim = dim
        self.dim_head = dim_head
        self.heads = heads
        self.depth = depth
        self.attn_dropout = attn_dropout
        self.ff_dropout = ff_dropout
        self.image_size = image_size

        self.layers = self.make_layers(depth=self.depth, dim=dim, heads=heads, dim_head=dim_head)
        self.to_out = nn.LayerNorm(dim)

    def make_layers(self, depth=1, dim=256, heads=12, dim_head=256):
        layers = nn.ModuleList([])

        for _ in range(depth):
            layers.append(nn.ModuleList([
                PreNorm(dim, Attention(dim, dim_head=dim_head, heads=heads, dropout=self.attn_dropout)),
                PreNorm(dim, FeedForward(dim, dropout=self.ff_dropout))
            ]))

        return layers

    def exec_layers(self, x, layers=None):
        if layers is None:
            return

        for (spatial_attn, ff) in layers:
            x = spatial_attn(x) + x
            running_print("{}|TimeSformer - Attention - ff -> residual -> x:{}\t\t{}", (st1, _st1, list(x.size())))

            x = ff(x) + x
            running_print("{}|TimeSformer - Attention - ff -> residual -> x:{}\t\t{}", (st1, _st1, list(x.size())))

        return x

    def pos_embedding(self, x, embedding=None, token=None):
        b, _, h, w, device, p = *x.shape, x.device, self.patch_size
        assert h % p == 0 and w % p == 0, f'height {h} and width {w} of video must be divisible by the patch size {p}'

        tokens = rearrange(x, 'b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1=p, p2=p)
        running_print("{}|TimeSformer - size of rearrange -> tokens:{}\t\t{}", (st1, _st1, list(tokens.size())))

        cls_token = repeat(token, 'n d -> b n d', b=b)                                                         # [1, 256] -> [8, 1, 256]
        x = torch.cat((cls_token, tokens), dim=1)                                        # [8, 784, 256], [8, 784, 256] -> [8, 785, 256]
        x += embedding(torch.arange(x.shape[1], device=device))                                                          # [128, 65, 96]
        running_print("{}|TimeSformer - size of x:{}\t\t\t\t{}\n", (st1, _st1, list(x.size())))

        return x

    def forward(self, x):
        running_print("{} {}{}", (st1, '_' * 100, _st1))
        running_print("{}|TimeSformer - image:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))

        init_x = x
        x = self.pos_embedding(x, embedding=self.pos_emb, token=self.cls_token)
        x = self.exec_layers(x, layers=self.layers)

        x = self.to_out(x)
        x = x[:, 1:, :]
        x = x.reshape((x.shape[0], self.image_size, self.image_size, x.shape[2]))
        x = x.permute(0, 3, 1, 2)
        running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))                                # [128, 96, 8, 8]
        running_print("{} {}{}", (st1, '-' * 100, _st1))

        x = x + init_x

        return x
