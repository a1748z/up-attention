import torch
from torch import nn, einsum
import torch.nn.functional as F
from einops import rearrange, repeat
from util_scripts.print_info import running_print, st1, _st1


# classes

class PreNorm(nn.Module):
    def __init__(self, dim, dim_query, split=False, fn=None):
        super().__init__()
        self.split = split
        self.fn = fn
        if self.split:
            self.norm1 = nn.LayerNorm(dim)
            self.norm2 = nn.LayerNorm(dim_query)
        else:
            self.norm = nn.LayerNorm(dim)

    def forward(self, x, *args, **kwargs):
        if self.split:
            x1, x2 = x[0], x[1]
            running_print("{}Up Attention\t - PreNorm - x1:{}\t\t\t\t{}", (st1, _st1, list(x1.size())))
            running_print("{}Up Attention\t - PreNorm - x2:{}\t\t\t\t{}", (st1, _st1, list(x2.size())))

            x1 = self.norm1(x1)
            x2 = self.norm2(x2)
            return self.fn([x1, x2], *args, **kwargs)
        else:
            running_print("{}Up Attention\t - PreNorm - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))
            x = self.norm(x)
            return self.fn(x, *args, **kwargs)

# feedforward

class GEGLU(nn.Module):
    def forward(self, x):
        x, gates = x.chunk(2, dim=-1)
        return x * F.gelu(gates)

class FeedForward(nn.Module):
    def __init__(self, dim, dim_out=None, split=False, mult=4, dropout=0.):
        super().__init__()
        self.split = split
        self.net = nn.Sequential(
            nn.Linear(dim, dim * mult * 2),
            GEGLU(),
            nn.Dropout(dropout),
            nn.Linear(dim * mult, dim if dim_out is None else dim_out)
        )

    def forward(self, x):
        running_print("{}Up Attention\t - FeedForward - x:{}\t\t\t\t{}", (st1, _st1, list(x.size())))
        return self.net(x)

# attention

# [32, 1, 36] -> [32, 6273, 36], [32, 6273, 36]
def attn(q, k, v):
    running_print("{}Up Attention\t - attn - q-k-v:{}\t\t\t\t{}-{}-{}", (st1, _st1, list(q.size()), list(k.size()), list(v.size())))

    sim = einsum('b i d, b j d -> b i j', q, k)                                          # [32, 1, 36] x [32, 6273, 36] = [32, 1, 6273]
    attn = sim.softmax(dim=-1)                                                           # [32, 1, 6273]
    out = einsum('b i j, b j d -> b i d', attn, v)                                       # [32, 1, 6273] x [32, 6273, 36] = [32, 1, 36]

    running_print("{}Up Attention\t - attn - sim-attn-out:{}\t\t\t\t{}-{}-{}", (st1, _st1, list(sim.size()), list(attn.size()), list(out.size())))
    return out

class Attention(nn.Module):
    def __init__(
        self,
        dim,
        dim_inner,
        dim_out,
        heads=12,
        dropout=0.,
        split=False,
        dim_query=None,
    ):
        super().__init__()
        self.dim = dim
        self.dim_inner = dim_inner
        self.heads = heads
        self.dim_head = dim_inner // heads
        self.scale = dim_inner ** -0.5

        self.split = split

        if self.split:
            self.to_q = nn.Linear(dim_query, dim_inner, bias=False)
            self.to_kv1 = nn.Linear(dim, dim_inner * 2, bias=False)

            self.to_out = nn.Sequential(nn.Linear(dim_inner, dim_out),
                                        nn.Dropout(dropout))
        else:
            self.to_qkv = nn.Linear(dim, dim_inner * 3, bias=False)

            self.to_out = nn.Sequential(nn.Linear(dim_inner, dim_out),
                                        nn.Dropout(dropout))

    def forward(self, x, **einops_dims):
        if self.split:
            x1, x2 = x[0], x[1]                                                                    # [128, 1024, 96]-[128, 65, 96]
            running_print("{}Up Attention\t - Attention: x1-x2:{}\t\t\t\t{}-{}", (st1, _st1, list(x1.size()), list(x2.size())))

            h = self.heads                                                                         # 96-8-12
            running_print("{}Up Attention\t - Attention: dim-dim_inner-heads-dim_head:{}\t{}-{}-{}-{}",
                          (st1, _st1, self.dim, self.dim_inner, self.heads, self.dim_head))

            q = self.to_q(x2)
            k1, v1 = self.to_kv1(x1).chunk(2, dim=-1)
            q, k1, v1 = map(lambda t: rearrange(t, 'b n (h d) -> (b h) n d', h=h), (q, k1, v1))
            q *= self.scale
            running_print("{}Up Attention\t - Attention - q-k1-v1:{}\t\t\t\t{}-{}-{}",    # [1024, 65, 12]-[1024, 1024, 12]-[1024, 1024, 12]
                          (st1, _st1, list(q.size()), list(k1.size()), list(v1.size())))

            # splice out classification token at index 1
            cls_q, q_ = q[:, 0:1], q[:, 1:]

            # let classification token attend to key / values of all patches across time and space
            # [32, 1, 36] x [32, 6273, 36] = [32, 1, 6273] -> softmax -> [32, 1, 6273] x [32, 6273, 36] = [32, 1, 36]
            cls_out = attn(cls_q, k1, v1)

            # attention
            # [1024, 196, 36] x [1024, 197, 36] = [1024, 196, 197] -> softmax -> [1024, 196, 197] x [1024, 197, 36] = [1024, 196, 36]
            out = attn(q_, k1, v1)
            running_print("{}Up Attention\t - Attention: out:{}\t\t\t\t{}", (st1, _st1, list(out.size())))

            # concat back the cls token: ([32, 1, 36], [32, 6272, 36]) -> [32, 6273, 36]
            out = torch.cat((cls_out, out), dim=1)
            running_print("{}Up Attention\t - Attention: out:{}\t\t\t\t{}", (st1, _st1, list(out.size())))

            # merge back the heads: [1024, 65, 12] -> [128, 65, 96]
            out = rearrange(out, '(b h) n d -> b n (h d)', h=h)
            running_print("{}Up Attention\t - Attention: out:{}\t\t\t\t{}", (st1, _st1, list(out.size())))

            # combine heads out
            return self.to_out(out)    # ********
        else:
            h = self.heads
            running_print("{}Up Attention\t - Attention - dim-heads-dim_head:{}\t{}-{}-{}", (st1, _st1, self.dim, self.heads, self.dim_head))
            q, k, v = self.to_qkv(x).chunk(3, dim=-1)
            q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> (b h) n d', h=h), (q, k, v))
            running_print("{}Up Attention\t - Attention - q-k-v:{}\t\t\t{}-{}-{}",
                          (st1, _st1, list(q.size()), list(k.size()), list(v.size())))

            q *= self.scale

            # splice out classification token at index 1
            (cls_q, q_), (cls_k, k_), (cls_v, v_) = map(lambda t: (t[:, 0:1], t[:, 1:]), (q, k, v))

            # let classification token attend to key / values of all patches across time and space
            cls_out = attn(cls_q, k, v)

            # expand cls token keys and values across time or space and concat
            r = q_.shape[0] // cls_k.shape[0]
            cls_k, cls_v = map(lambda t: repeat(t, 'b () d -> (b r) () d', r=r), (cls_k, cls_v))

            k_ = torch.cat((cls_k, k_), dim=1)
            v_ = torch.cat((cls_v, v_), dim=1)

            # attention
            out = attn(q_, k_, v_)

            # concat back the cls token
            out = torch.cat((cls_out, out), dim=1)

            # merge back the heads
            out = rearrange(out, '(b h) n d -> b n (h d)', h=h)

            # combine heads out
            return self.to_out(out)
