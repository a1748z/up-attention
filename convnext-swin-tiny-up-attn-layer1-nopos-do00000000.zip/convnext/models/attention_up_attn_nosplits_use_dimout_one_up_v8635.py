import torch
from torch import nn, einsum
import torch.nn.functional as F
from einops import rearrange, repeat
from util_scripts.print_info import running_print, st1, _st1, st2, _st2

from models.csc_layer_v8 import DictBlock, DictConv2d


# classes

class PreNorm(nn.Module):
    def __init__(self, dim, dim_query, split=False, fn=None):
        super().__init__()
        self.split = split
        self.fn = fn
        if self.split:
            self.norm1 = nn.LayerNorm(dim)
            self.norm2 = nn.LayerNorm(dim_query)
        else:
            self.norm = nn.LayerNorm(dim)

    def forward(self, x, *args, **kwargs):
        if self.split:
            x1, x2 = x[0], x[1]
            running_print("{}|PreNorm - x1:{}\t\t\t\t\t\t{}", (st1, _st1, list(x1.size())))
            running_print("{}|PreNorm - x2:{}\t\t\t\t\t\t{}", (st1, _st1, list(x2.size())))

            x1 = self.norm1(x1)
            x2 = self.norm2(x2)
            return self.fn([x1, x2], *args, **kwargs)
        else:
            running_print("{}|PreNorm - x:{}\t\t\t\t\t\t{}", (st1, _st1, list(x.size())))
            x = self.norm(x)
            return self.fn(x, *args, **kwargs)

# feedforward

class GEGLU(nn.Module):
    def forward(self, x):
        x, gates = x.chunk(2, dim=-1)
        return x * F.gelu(gates)

class FeedForward(nn.Module):
    def __init__(self, dim, dim_out=None, split=False, mult=4, dropout=0.):
        super().__init__()
        self.split = split
        self.net = nn.Sequential(
            nn.Linear(dim, dim * mult * 2),
            GEGLU(),
            nn.Dropout(dropout),
            nn.Linear(dim * mult, dim if dim_out is None else dim_out)
        )

    def forward(self, x):
        running_print("{}|FeedForward - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))
        return self.net(x)

# attention

# [32, 1, 36] -> [32, 6273, 36], [32, 6273, 36]
def attn(q, k, v):
    running_print("{}|attn - q-k-v:{}\t\t\t\t\t\t{}-{}-{}", (st1, _st1, list(q.size()), list(k.size()), list(v.size())))

    sim = einsum('b i d, b j d -> b i j', q, k)                                          # [32, 1, 36] x [32, 6273, 36] = [32, 1, 6273]
    attn = sim.softmax(dim=-1)                                                           # [32, 1, 6273]
    out = einsum('b i j, b j d -> b i d', attn, v)                                       # [32, 1, 6273] x [32, 6273, 36] = [32, 1, 36]

    running_print("{}|attn - sim-attn-out:{}\t\t\t\t\t{}-{}-{}", (st1, _st1, list(sim.size()), list(attn.size()), list(out.size())))
    return out

class Attention(nn.Module):
    def __init__(
        self,
        dim,
        dim_inner,
        dim_out,
        heads=12,
        dropout=0.,
        split=False,
        dim_query=None,
    ):
        super().__init__()
        self.dim = dim
        self.dim_inner = dim_inner
        self.heads = heads
        self.dim_head = dim_inner // heads
        self.scale = dim_inner ** -0.5

        self.split = split

        if self.split:
            self.to_q = nn.Linear(dim_query, dim_inner, bias=False)
            self.to_kv1 = nn.Linear(dim, dim_inner * 2, bias=False)

            self.to_out = nn.Sequential(nn.Linear(dim_inner, dim_out),
                                        nn.Dropout(dropout))
        else:
            self.to_qkv = nn.Linear(dim, dim_inner * 3, bias=False)

            self.to_out = nn.Sequential(nn.Linear(dim_inner, dim_out),
                                        nn.Dropout(dropout))

    def forward(self, x, **einops_dims):
        if self.split:
            x1, x2 = x[0], x[1]                                                                    # [128, 1024, 96]-[128, 65, 96]
            running_print("{}|Attention: x1-x2:{}\t\t\t\t\t{}-{}", (st1, _st1, list(x1.size()), list(x2.size())))

            h = self.heads                                                                         # 96-8-12
            running_print("{}|Attention: dim-dim_inner-heads-dim_head:\t\t{}-{}-{}-{}{}",
                          (st2, self.dim, self.dim_inner, self.heads, self.dim_head, _st2))

            q = self.to_q(x2)
            k1, v1 = self.to_kv1(x1).chunk(2, dim=-1)
            q, k1, v1 = map(lambda t: rearrange(t, 'b n (h d) -> (b h) n d', h=h), (q, k1, v1))
            q *= self.scale
            running_print("{}|Attention - q-k1-v1:{}\t\t\t\t\t{}-{}-{}",    # [1024, 65, 12]-[1024, 1024, 12]-[1024, 1024, 12]
                          (st1, _st1, list(q.size()), list(k1.size()), list(v1.size())))

            # splice out classification token at index 1
            cls_q, q_ = q[:, 0:1], q[:, 1:]

            # let classification token attend to key / values of all patches across time and space
            # [32, 1, 36] x [32, 6273, 36] = [32, 1, 6273] -> softmax -> [32, 1, 6273] x [32, 6273, 36] = [32, 1, 36]
            cls_out = attn(cls_q, k1, v1)

            # attention
            # [1024, 196, 36] x [1024, 197, 36] = [1024, 196, 197] -> softmax -> [1024, 196, 197] x [1024, 197, 36] = [1024, 196, 36]
            out = attn(q_, k1, v1)
            running_print("{}|Attention: out:{}\t\t\t\t\t{}", (st1, _st1, list(out.size())))

            # concat back the cls token: ([32, 1, 36], [32, 6272, 36]) -> [32, 6273, 36]
            out = torch.cat((cls_out, out), dim=1)
            running_print("{}|Attention: out:{}\t\t\t\t\t{}", (st1, _st1, list(out.size())))

            # merge back the heads: [1024, 65, 12] -> [128, 65, 96]
            out = rearrange(out, '(b h) n d -> b n (h d)', h=h)
            running_print("{}|Attention: out:{}\t\t\t\t\t{}", (st1, _st1, list(out.size())))

            # combine heads out
            return self.to_out(out)    # ********
        else:
            h = self.heads
            running_print("{}|Attention: dim-dim_inner-heads-dim_head:\t\t{}-{}-{}-{}{}",
                          (st2, self.dim, self.dim_inner, self.heads, self.dim_head, _st2))
            q, k, v = self.to_qkv(x).chunk(3, dim=-1)
            q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> (b h) n d', h=h), (q, k, v))
            running_print("{}|Attention - q-k-v:{}\t\t\t\t\t{}-{}-{}",
                          (st1, _st1, list(q.size()), list(k.size()), list(v.size())))

            q *= self.scale

            # splice out classification token at index 1
            (cls_q, q_), (cls_k, k_), (cls_v, v_) = map(lambda t: (t[:, 0:1], t[:, 1:]), (q, k, v))

            # let classification token attend to key / values of all patches across time and space
            cls_out = attn(cls_q, k, v)

            # expand cls token keys and values across time or space and concat
            r = q_.shape[0] // cls_k.shape[0]
            cls_k, cls_v = map(lambda t: repeat(t, 'b () d -> (b r) () d', r=r), (cls_k, cls_v))

            k_ = torch.cat((cls_k, k_), dim=1)
            v_ = torch.cat((cls_v, v_), dim=1)

            # attention
            out = attn(q_, k_, v_)

            # concat back the cls token
            out = torch.cat((cls_out, out), dim=1)

            # merge back the heads
            out = rearrange(out, '(b h) n d -> b n (h d)', h=h)

            # combine heads out
            return self.to_out(out)


# main classes
class TimeSformer(nn.Module):
    def __init__(self,
                 *,
                 dim,
                 dim_query=256,
                 dim_out=256,
                 image_size=224,
                 patch_size=1,
                 depth=12,
                 heads=8,
                 heads_query=8,
                 attn_dropout=0.,
                 ff_dropout=0.,
                 query_size=224
                 ):
        super().__init__()
        assert image_size % patch_size == 0, 'Image dimensions must be divisible by the patch size.'

        num_positions = (image_size // patch_size) ** 2
        query_positions = (query_size ** 2) + 1

        self.image_size = image_size
        self.query_size = query_size
        self.patch_size = patch_size
        self.dim_query = dim_query
        self.depth = depth
        self.attn_dropout = attn_dropout
        self.ff_dropout = ff_dropout
        self.dim_out = dim_out

        self.pos_emb = nn.Embedding(num_positions, dim)
        self.query_emb = nn.Embedding(query_positions, dim_query)
        self.cls_token = nn.Parameter(torch.randn(1, dim_query))
        self.dim_out = dim_out

        self.layer = self.make_layers(depth=depth, dim=dim, dim_query=dim_query, dim_out=dim_out, heads=heads, heads_query=heads_query)

        self.to_out = nn.LayerNorm(dim_out)

        self.sparsify_image = nn.Sequential(
            DictConv2d(dim, dim, kernel_size=2, stride=2, padding=0, bias=False,
                       zsize=(dim, self.image_size//2, self.image_size//2), groups=dim),
            nn.BatchNorm2d(dim),
            # nn.ReLU(inplace=True),
        )

        self.sparsify_query = nn.Sequential(
            DictConv2d(self.dim_query, self.dim_query, kernel_size=3, stride=1, padding=1, bias=False,
                       zsize=(self.dim_query, self.query_size, self.query_size), groups=self.dim_query),
            nn.BatchNorm2d(self.dim_query),
            # nn.ReLU(inplace=True),
        )

    def sparsify(self, x, h, w, sparse, cls=False):
        if cls:
            cls_token = x[:, 0:1, :]
            running_print("{}|TimeSformer - cls_token:{}\t\t\t\t{}", (st1, _st1, list(cls_token.size())))      # [128, 8, 8, 96]

            x = x[:, 1:, :]
            running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))              # [128, 8, 8, 96]

        x = rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)
        running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))

        x = sparse(x)
        running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))              # [128, 96, 8, 8]

        x = rearrange(x, 'b c h w -> b (h w) c')
        running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))

        if cls:
            x = torch.cat((cls_token, x), dim=1)
            running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))

        return x

    def make_layers(self, depth=1, dim=256, dim_query=256, dim_out=256, heads=12, heads_query=12):
        layers = nn.ModuleList([])
        for _ in range(depth):
            layers.append(nn.ModuleList([
                PreNorm(dim, dim_query, True, Attention(dim, dim, dim_out, heads, self.attn_dropout, True, dim_query)),
                PreNorm(dim_out, dim_out, False, FeedForward(dim_out, dim_out=dim_out, split=False, dropout=self.ff_dropout)),
                PreNorm(dim_out, dim_out, False, Attention(dim_out, dim_out, dim_out, heads_query, self.attn_dropout, False)),
                PreNorm(dim_out, dim_out, False, FeedForward(dim_out, dim_out=dim_out, split=False, dropout=self.ff_dropout))
            ]))

        return layers

    def exec_layers(self, x, layers=None):
        if layers is None:
            return

        for (up_attention, ff1, self_attention, ff2) in layers:
            up, query = x[0], x[1]
            running_print("{}|TimeSformer -> up:{}\t\t\t\t\t{}\n", (st1, _st1, list(up.size())))
            up = self.sparsify(up, self.image_size, self.image_size, self.sparsify_image, cls=False)

            x = up_attention([up, query]) + query                                                    # [128, 65, 96]
            running_print("{}|TimeSformer - up_attention1 -> x:{}\t\t\t{}\n", (st1, _st1, list(x.size())))

            x = ff1(x) + x
            running_print("{}|TimeSformer - ff1 -> residual -> x:{}\t\t\t{}\n", (st1, _st1, list(x.size())))

            x = self_attention(self.sparsify(x, self.query_size, self.query_size, self.sparsify_query, cls=True)) + x
            running_print("{}|TimeSformer - self_attention -> x:{}\t\t\t{}\n", (st1, _st1, list(x.size())))

            x = ff2(x) + x
            running_print("{}|TimeSformer - ff2 -> residual -> x:{}\t\t\t{}\n", (st1, _st1, list(x.size())))

        return x

    def to_tokens(self, x):
        b, _, h, w, device, p = *x.shape, x.device, self.patch_size
        assert h % p == 0 and w % p == 0, f'height {h} and width {w} of image must be divisible by the patch size {p}'

        tokens = rearrange(x, 'b c (h p1) (w p2) -> b (h w) (p1 p2 c)', p1=p, p2=p)

        return tokens, b, device

    def pos_embedding(self, images, embedding, query_embedding, token):
        v, q = images[0], images[1]                                                                  # [128, 96, 32, 32]-[128, 96, 8, 8]
        v, b, device = self.to_tokens(v)                                                             # [128, 1024, 96]
        q, _, _ = self.to_tokens(q)                                                                  # [b, h*w, c]
        running_print("{}|TimeSformer - v-q:{}\t\t\t\t\t{}-{}", (st1, _st1, list(v.size()), list(q.size())))

        v = v + embedding(torch.arange(v.shape[1], device=device))                                   # [128, 1024, 96]

        cls_token = repeat(token, 'n d -> b n d', b=b)
        q = torch.cat((cls_token, q), dim=1)                                                         # [128, 65, 96]
        q = q + query_embedding(torch.arange(q.shape[1], device=device))
        running_print("{}|TimeSformer - v-q:{}\t\t\t\t\t{}-{}", (st1, _st1, list(v.size()), list(q.size())))

        return [v, q]
        # return [v1.contiguous(), v2.contiguous()]

    def forward(self, images):
        image, query = images[0], images[1]                                                          # [128, 96, 32, 32]-[128, 96, 8, 8]
        running_print("{} {}{}", (st1, '-' * 100, _st1))
        running_print("{}|TimeSformer - image-query:{}\t\t\t\t{}-{}", (st1, _st1, list(image.size()), list(query.size())))
        assert self.image_size == image.size()[-1], 'Declared image size should equal to real image size.'

        init_x = query

        image_list = self.pos_embedding([image, query], self.pos_emb, self.query_emb, self.cls_token)

        x = self.exec_layers(image_list, layers=self.layer)
        running_print("{}|TimeSformer - image after exec:{}\t\t\t{}", (st1, _st1, list(x.size())))   # [4, 6273, 128]

        x = self.to_out(x)

        token = x[:, 0, :]
        running_print("{}|TimeSformer - token:{}\t\t\t\t\t{}", (st1, _st1, list(token.size())))      # [128, 8, 8, 96]

        x = x[:, 1:, :]
        x = x.reshape((x.shape[0], self.query_size, self.query_size, x.shape[2]))
        running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))              # [128, 8, 8, 96]

        x = x.permute(0, 3, 1, 2)
        running_print("{}|TimeSformer - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))              # [128, 96, 8, 8]
        running_print("{} {}{}", (st1, '-' * 100, _st1))

        x = x + init_x

        return x, token
