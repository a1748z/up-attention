# Copyright (c) Meta Platforms, Inc. and affiliates.

# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.


import torch
import torch.nn as nn
import torch.nn.functional as F
from timm.models.layers import trunc_normal_, DropPath
from timm.models.registry import register_model

from rich import print
from util_scripts.print_info import pre_print, running_print, st1, _st1
from models.attention import TimeSformer as Self_Attention
from models.attention_up_attn_nosplits_use_dimout_one_up_v8647 import TimeSformer as Up_Attention_One_Up
from models.attention_up_attn_nosplits_use_dimout_three_up_v38 import TimeSformer as Up_Attention_Three_Up
from models.attention_pool_v2 import TimeSformer as Attention_Pool

from models.csc_layer_v6 import DictBlock, DictConv2d


class Block(nn.Module):
    r""" ConvNeXt Block. There are two equivalent implementations:
    (1) DwConv -> LayerNorm (channels_first) -> 1x1 Conv -> GELU -> 1x1 Conv; all in (N, C, H, W)
    (2) DwConv -> Permute to (N, H, W, C); LayerNorm (channels_last) -> Linear -> GELU -> Linear; Permute back
    We use (2) as we find it slightly faster in PyTorch
    
    Args:
        dim (int): Number of input channels.
        drop_path (float): Stochastic depth rate. Default: 0.0
        layer_scale_init_value (float): Init value for Layer Scale. Default: 1e-6.
    """
    def __init__(self, dim, drop_path=0., layer_scale_init_value=1e-6, layer=0, block=0):
        super().__init__()

        # depths: tiny-[3, 3, 9, 3], small-[3, 3, 27, 3]
        # dims:   tiny-[96, 192, 384, 768], small-[96, 192, 384, 768]
        self.dim = dim
        if layer == 1:
            image_sizes_up1 = 32                           # size of x_up, 224 x 224 size:  56
            image_sizes = 32                               # size of x, 224 x 224 size:     56
            space_divisions_up1 = 1                        # for reshaping to get x
            depth = 1
            heads = 8     # -> 6
            # *cardinality = 8
        elif layer == 2:
            self.up2_splits = 2
            image_sizes_up1 = 32                           # size of x_up, 224 x 224 size:  56
            image_sizes_up2 = 16                           # size of x_up, 224 x 224 size:  28
            image_sizes = 16                               # size of x, 224 x 224 size:     28
            space_divisions_up1 = 2                        # for reshaping to get x
            space_divisions_up2 = 1                        # for reshaping to get x
            dim_division_up1 = 2
            dim_division_up2 = 1
            depth = 1
            heads1 = 6
            heads2 = 6
            # *cardinality = 8
        elif layer == 3:
            self.up3_splits = 2
            image_sizes_up1 = 32                           # size of x_up, 224 x 224 size:  56
            image_sizes_up2 = 16                           # size of x_up, 224 x 224 size:  28
            image_sizes_up3 = 8                            # size of x_up, 224 x 224 size:  14
            image_sizes = 8                                # size of x, 224 x 224 size:     14
            space_divisions_up1 = 4                        # for reshaping to get x
            space_divisions_up2 = 2                        # for reshaping to get x
            dim_division_up1 = 4
            dim_division_up2 = 2
            dim_division_up3 = 1
            depth = 1
            heads1 = 8
            heads2 = 8
            heads3 = 8
            # *cardinality = 8
        elif layer == 4:
            self.up4_splits = 2                                # *should accord to self.up4_splits in class ConvNext
            self.dim1 = dim // 8
            self.dim2 = dim // 4
            self.dim3 = dim // 4
            self.dim_query = dim // self.up4_splits
            self.dim_out = dim // self.up4_splits
            self.image_size_up1 = 32                           # size of x_up, 224 x 224 size:  56
            self.image_size_up2 = 16                           # size of x_up, 224 x 224 size:  28
            self.image_size_up3 = 16                            # size of x_up, 224 x 224 size:  14
            self.query_size = 8
            depth = 1
            heads1 = 6
            heads2 = 12
            heads3 = 12
            heads4 = 12

        if (layer == 4 and block in [3]):
            self.up_attention = nn.Sequential(Up_Attention_One_Up(dim=self.dim1,
                                                                  dim_query=self.dim_query, dim_out=self.dim_out,
                                                                  image_size=self.image_size_up1,
                                                                  query_size=self.query_size,
                                                                  depth=depth, heads=heads1, heads_query=heads4,
                                                                  attn_dropout=0.1, ff_dropout=0.1))
            
            # self.up_conv = nn.Conv2d(self.dim_out, dim, kernel_size=4, padding=0, stride=4, groups=self.dim_out)

            self.dwconv = nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim) # depthwise conv
            self.norm = LayerNorm(dim, eps=1e-6)

            self.pwconv1 = nn.Linear(dim, 4 * dim) # pointwise/1x1 convs, implemented with linear layers
            self.act = nn.GELU()
        elif layer == 4:
            self.dwconv = nn.Conv2d(dim, dim, kernel_size=3, padding=1, groups=dim) # depthwise conv
            self.norm = LayerNorm(dim, eps=1e-6)

            self.pwconv1 = nn.Linear(dim, 4 * dim) # pointwise/1x1 convs, implemented with linear layers
            self.act = nn.GELU()
        else:
            self.dwconv = nn.Conv2d(dim, dim, kernel_size=5, padding=2, groups=dim) # depthwise conv
            self.norm = LayerNorm(dim, eps=1e-6)

            self.pwconv1 = nn.Linear(dim, 4 * dim) # pointwise/1x1 convs, implemented with linear layers
            self.act = nn.GELU()

        self.pwconv2 = nn.Linear(4 * dim, dim)
        self.gamma = nn.Parameter(layer_scale_init_value * torch.ones((dim)), 
                                    requires_grad=True) if layer_scale_init_value > 0 else None

        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.relu = nn.ReLU(inplace=True)

        self.layer = layer
        self.block = block

    def forward(self, x):
        if self.layer == 1:
            x_up1, x = x[0], x[1]
        elif self.layer == 2:
            x_up1, x_up2, x = x[0], x[1], x[2]
        elif self.layer == 3:
            x_up1, x_up2, x_up3, x = x[0], x[1], x[2], x[3]
        elif self.layer == 4:
            x_up1, x_up2, x_up3, x_up4, x = x[0], x[1], x[2], x[3], x[4]

        input = x

        
        x = self.dwconv(x)
        running_print("{}ConvNeXt layer {} block {} \t - dwconv -> x:{}\t\t{}", (st1, self.layer, self.block, _st1, list(x.size())))

        x = x.permute(0, 2, 3, 1) # (N, C, H, W) -> (N, H, W, C)
        x = self.norm(x)
        running_print("{}ConvNeXt layer {} block {} \t - permute -> x:{}\t{}", (st1, self.layer, self.block, _st1, list(x.size())))

        x = self.pwconv1(x)
        x = self.act(x)
        running_print("{}ConvNeXt layer {} block {} \t - pwconv1 -> x:{}\t{}", (st1, self.layer, self.block, _st1, list(x.size())))

        x = self.pwconv2(x)
        if self.gamma is not None:
            x = self.gamma * x
        running_print("{}ConvNeXt layer {} block {} \t - pwconv2 -> x:{}\t{}", (st1, self.layer, self.block, _st1, list(x.size())))

        x = x.permute(0, 3, 1, 2) # (N, H, W, C) -> (N, C, H, W)
        running_print("{}ConvNeXt layer {} block {} \t - permute -> x:{}\t{}", (st1, self.layer, self.block, _st1, list(x.size())))

        x = input + self.drop_path(x)
        running_print("{}ConvNeXt layer {} block {} \t - resplus -> x:{}\t{}", (st1, self.layer, self.block, _st1, list(x.size())))
        running_print("\n")

        if self.layer == 1 and self.block in [3]:
            x_up1 = x
        elif self.layer == 4 and self.block in [2, 3]:
            for i in range(self.up4_splits):
                x_up4.append(x[:, self.dim*i//self.up4_splits:self.dim*(i+1)//self.up4_splits, :, :])

        if (self.layer == 4 and self.block in [3]):
            # new_up4 -------------------------------------------------------------------------------------------------------------------------------
            xs = []
            for i in range(len(x_up4)):
                xl = x_up4[i]
                running_print("{}ConvNeXt layer {} block {} \t - slice -> xl:{}\t\t{}", (st1, self.layer, self.block, _st1, list(xl.size())))

                xl = xl.view([x.shape[0], x.shape[1]//self.up4_splits, -1])
                running_print("{}ConvNeXt layer {} block {} \t - slice -> xl:{}\t\t{}", (st1, self.layer, self.block, _st1, list(xl.size())))

                xs.append(xl)

            new_up4 = torch.cat(xs, dim=-1)
            running_print("{}ConvNeXt layer {} block {} \t - cat -> new_up4:{}\t{}", (st1, self.layer, self.block, _st1, list(new_up4.size())))

            new_up4 = new_up4.view(x.shape[0], x.shape[1]//self.up4_splits, self.query_size, self.query_size)
            running_print("{}ConvNeXt layer {} block {} \t - view -> new_up4:{}\t{}\n", (st1, self.layer, self.block, _st1, list(new_up4.size())))

            _, token = self.up_attention([x_up1, new_up4])

            '''
            up_conv = self.up_conv(up_attention)
            running_print("{}ConvNeXt layer {} block {} \t - up-conv -> up_conv:{}\t\t{}", (st1, self.layer, self.block, _st1, list(up_conv.size())))

            x = torch.cat((up_conv, x), dim=1)'''

        if self.layer == 1:
            return [x_up1, x]
        elif self.layer == 2:
            return [x_up1, x_up2, x]    # return [x_up1, x_up1, x]
        elif self.layer == 3:
            return [x_up1, x_up2, x_up3, x]
        elif self.layer == 4 and self.block != 3:
            return [x_up1, x_up2, x_up3, x_up4, x]
        elif self.layer == 4 and self.block == 3:
            return [x, token]
        else:
            return x

class ConvNeXt(nn.Module):
    r""" ConvNeXt
        A PyTorch impl of : `A ConvNet for the 2020s`  -
          https://arxiv.org/pdf/2201.03545.pdf

    Args:
        in_chans (int): Number of input image channels. Default: 3
        num_classes (int): Number of classes for classification head. Default: 1000
        depths (tuple(int)): Number of blocks at each stage. Default: [3, 3, 9, 3]
        dims (int): Feature dimension at each stage. Default: [96, 192, 384, 768]
        drop_path_rate (float): Stochastic depth rate. Default: 0.
        layer_scale_init_value (float): Init value for Layer Scale. Default: 1e-6.
        head_init_scale (float): Init scaling value for classifier weights and biases. Default: 1.
    """
    def __init__(self, in_chans=3, num_classes=1000, 
                 depths=[3, 3, 9, 3], dims=[96, 192, 384, 768], drop_path_rate=0., 
                 layer_scale_init_value=1e-6, head_init_scale=1.,
                 ):
        super().__init__()
        sizes = [32, 16, 8, 4]
        attn_depth = 1
        heads = [4, 8, 8, 8]
        self.up4_splits = 2                                # *should accord to self.up4_splits in class Block

        self.downsample_layers = nn.ModuleList()                                         # stem and 3 intermediate downsampling conv layers
        stem = nn.Sequential(nn.Conv2d(in_chans, dims[0], kernel_size=5, padding=2, stride=1),
                             LayerNorm(dims[0], eps=1e-6, data_format="channels_first"))
        self.downsample_layers.append(stem)
        for i in range(3):
            downsample_layer = nn.Sequential(LayerNorm(dims[i], eps=1e-6, data_format="channels_first"),
                                             nn.Conv2d(dims[i], dims[i+1], kernel_size=2, stride=2),)
            self.downsample_layers.append(downsample_layer)

        self.stages = nn.ModuleList() # 4 feature resolution stages, each consisting of multiple residual blocks
        dp_rates=[x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))] 
        cur = 0
        for i in range(4):
            stage = nn.Sequential(
                *[Block(dim=dims[i], drop_path=dp_rates[cur + j], 
                layer_scale_init_value=layer_scale_init_value, layer=i + 1, block=j + 1) for j in range(depths[i])]
            )
            self.stages.append(stage)
            cur += depths[i]

        self.norm = nn.LayerNorm(dims[-1] + dims[-1]//self.up4_splits, eps=1e-6)         # final norm layer
        self.head = nn.Linear(dims[-1] + dims[-1]//self.up4_splits, num_classes)

        self.apply(self._init_weights)
        self.head.weight.data.mul_(head_init_scale)
        self.head.bias.data.mul_(head_init_scale)

    def _init_weights(self, m):
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        else:
            # print("{} is not the instance of nn ...".format(type(m)))
            pass

    def update_stepsize(self):
        running_print("\n{}updating stepsize ...{}", (st1, _st1))

        for m in self.modules():
            if isinstance(m, DictBlock):
                m.update_stepsize()

    def reset_dictblock_state(self, it=0, c_pre=None, c=None, t=0, state=None):
        running_print("\n{}resetting dictblock state ...{}", (st1, _st1))

        for m in self.modules():
            if isinstance(m, DictBlock):
                m.reset_dictblock_state(it=it, c_pre=c_pre, c=c, t=t, state=state)

    def get_rc(self):
        running_print("\n{}getting rc ...{}", (st1, _st1))

        rc_list = []
        for m in self.modules():
            if isinstance(m, DictConv2d):
                rc_list.append(m.get_rc())

        return rc_list

    def forward_features(self, x):
        running_print("\n{}ConvNeXt layer 1 {}{}", (st1, '-'*66, _st1))
        x = self.downsample_layers[0](x)
        x_up1 = []
        x = self.stages[0]([x_up1, x])

        running_print("\n{}ConvNeXt layer 2 {}{}", (st1, '-'*66, _st1))
        x_up1, x = x[0], x[1]
        x = self.downsample_layers[1](x)
        running_print("\n{}ConvNeXt downsampled x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))
        x_up2 = []
        x = self.stages[1]([x_up1, x_up2, x])

        running_print("\n{}ConvNeXt layer 3 {}{}", (st1, '-'*66, _st1))
        x_up1, x_up2, x = x[0], x[1], x[2]
        x = self.downsample_layers[2](x)
        x_up3 = []
        x = self.stages[2]([x_up1, x_up2, x_up3, x])

        running_print("\n{}ConvNeXt layer 4 {}{}", (st1, '-'*66, _st1))
        x_up1, x_up2, x_up3, x = x[0], x[1], x[2], x[3]
        x = self.downsample_layers[3](x)
        x_up4 = []
        x, token = self.stages[3]([x_up1, x_up2, x_up3, x_up4, x])
        running_print("\n{}ConvNeXt after stages -> x-token:{}\t\t\t\t{}-{}\n", (st1, _st1, list(x.size()), list(token.size())))

        x = x.mean([-2, -1])
        running_print("\n{}ConvNeXt after stages -> x:{}\t\t\t\t\t{}\n", (st1, _st1, list(x.size())))

        x = torch.cat([x, token], dim=1)
        running_print("\n{}ConvNeXt after cat -> x:{}\t\t\t\t\t{}\n", (st1, _st1, list(x.size())))

        return self.norm(x) # global average pooling, (N, C, H, W) -> (N, C)

    def forward(self, x):
        running_print("\n{}ConvNeXt init x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))
        x = self.forward_features(x)

        # Multi-Task Learning Using Uncertainty to Weigh Losses for Scene Geometry and Semantics
        # x = self.head1(x) / (3.0 * self.r1 * self.r1) + self.head2(token1) / (3.0 * self.r2 * self.r2) + self.head3(token2) / (3.0 * self.r3 * self.r3) \
        #     + torch.log(self.r1 * self.r2 * self.r3)

        # x = self.head1(x) * 0.00 + self.head2(token) * 1.00              # v80-82.94-83.29, may need more epochs
        # x = self.head1(x) * 0.999 + self.head2(token) * 0.001            # v71-84.34-84.84, v32-
        # x = self.head1(x) * 0.99 + self.head2(token) * 0.01              # v70-83.69-84.58, v33-
        # x = self.head1(x) * 0.90 + self.head2(token) * 0.10              # v72-84.28-84.83, v34-
        # x = self.head1(x) * 0.80 + self.head2(token) * 0.20              # v73-84.57-84.96, v35-
        # x = self.head1(x) * 0.70 + self.head2(token) * 0.30              # v74-84.18-84.76
        # x = self.head1(x) * 0.60 + self.head2(token) * 0.40              # v75-84.80-85.02
        # x = self.head1(x) * 0.50 + self.head2(token) * 0.50              # v76-84.96-85.31
        # x = self.head1(x) * 0.40 + self.head2(token) * 0.60              # v77-84.72-85.23
        # x = self.head1(x) * 0.30 + self.head2(token) * 0.70
        # x = self.head1(x) * 0.20 + self.head2(token) * 0.80
        # x = self.head1(x) * self.r + self.head2(token) * (1 - self.r)    # v78-84.61-85.05-r = 0.5
        # x = self.head1(x) * 1.00 + self.head2(token) * 0.00              # v81-84.12-84.67

        # x = self.head1(x) * self.r + self.head2(token) * (1 - self.r) + torch.log(self.r * (1.0 - self.r))

        # l4b5-up123-v11-84.51-85.16, tiny-imagenet-v03-71.90
        # x = self.head1(x) / (2.0 * self.r1 * self.r1) + self.head2(token) / (2.0 * self.r2 * self.r2) + torch.log(self.r1 * self.r2)

        x = self.head(x)
        running_print("\n{}ConvNeXt head \t\t\t - x:{}\t\t\t\t{}\n", (st1, _st1, list(x.size())))

        return x

class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first. 
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with 
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs 
    with shape (batch_size, channels, height, width).
    """
    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError 
        self.normalized_shape = (normalized_shape, )
    
    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x


model_urls = {
    "convnext_tiny_1k": "https://dl.fbaipublicfiles.com/convnext/convnext_tiny_1k_224_ema.pth",
    "convnext_small_1k": "https://dl.fbaipublicfiles.com/convnext/convnext_small_1k_224_ema.pth",
    "convnext_base_1k": "https://dl.fbaipublicfiles.com/convnext/convnext_base_1k_224_ema.pth",
    "convnext_large_1k": "https://dl.fbaipublicfiles.com/convnext/convnext_large_1k_224_ema.pth",
    "convnext_tiny_22k": "https://dl.fbaipublicfiles.com/convnext/convnext_tiny_22k_224.pth",
    "convnext_small_22k": "https://dl.fbaipublicfiles.com/convnext/convnext_small_22k_224.pth",
    "convnext_base_22k": "https://dl.fbaipublicfiles.com/convnext/convnext_base_22k_224.pth",
    "convnext_large_22k": "https://dl.fbaipublicfiles.com/convnext/convnext_large_22k_224.pth",
    "convnext_xlarge_22k": "https://dl.fbaipublicfiles.com/convnext/convnext_xlarge_22k_224.pth",
}

@register_model
def convnext_tiny(pretrained=False, pretrained_cfg=None, pretrained_cfg_overlay=None, in_22k=False, **kwargs):
    model = ConvNeXt(depths=[3, 3, 9, 5], dims=[96, 192, 384, 768], **kwargs)
    if pretrained:
        url = model_urls['convnext_tiny_22k'] if in_22k else model_urls['convnext_tiny_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu", check_hash=True)
        model.load_state_dict(checkpoint["model"])
    return model

@register_model
def convnext_small(pretrained=False, pretrained_cfg=None, pretrained_cfg_overlay=None, in_22k=False, **kwargs):
    model = ConvNeXt(depths=[3, 3, 27, 5], dims=[96, 192, 384, 768], **kwargs)
    if pretrained:
        url = model_urls['convnext_small_22k'] if in_22k else model_urls['convnext_small_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu")
        model.load_state_dict(checkpoint["model"])
    return model

@register_model
def convnext_base(pretrained=False, pretrained_cfg=None, pretrained_cfg_overlay=None, in_22k=False, **kwargs):
    model = ConvNeXt(depths=[3, 3, 9, 5], dims=[128, 256, 512, 1024], **kwargs)
    if pretrained:
        url = model_urls['convnext_base_22k'] if in_22k else model_urls['convnext_base_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu")
        model.load_state_dict(checkpoint["model"])
    return model

@register_model
def convnext_large(pretrained=False, pretrained_cfg=None, pretrained_cfg_overlay=None, in_22k=False, **kwargs):
    model = ConvNeXt(depths=[3, 3, 9, 3], dims=[192, 384, 768, 1536], **kwargs)
    if pretrained:
        url = model_urls['convnext_large_22k'] if in_22k else model_urls['convnext_large_1k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu")
        model.load_state_dict(checkpoint["model"])
    return model

@register_model
def convnext_xlarge(pretrained=False, pretrained_cfg=None, pretrained_cfg_overlay=None, in_22k=False, **kwargs):
    model = ConvNeXt(depths=[3, 3, 27, 5], dims=[256, 512, 1024, 2048], **kwargs)
    if pretrained:
        assert in_22k, "only ImageNet-22K pre-trained ConvNeXt-XL is available; please set in_22k=True"
        url = model_urls['convnext_xlarge_22k']
        checkpoint = torch.hub.load_state_dict_from_url(url=url, map_location="cpu")
        model.load_state_dict(checkpoint["model"])
    return model

'''

'''