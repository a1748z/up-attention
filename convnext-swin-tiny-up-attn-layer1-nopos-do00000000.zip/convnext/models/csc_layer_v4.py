from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import math
import numpy as np

import torch
import torch.nn as nn
import torch._utils
import torch.nn.functional as F
import torch.nn.init as init
from models.config import config

from util_scripts.print_info import pre_print, running_print, st1, _st1
from opts import get_args_parser

parser = get_args_parser()
args = parser.parse_args()


class elasnet_prox(nn.Module):
    r"""Applies the elastic net proximal operator,
    NOTS: it will degenerate to ell1_prox if mu=0.0

    The elastic net proximal operator function is given as the following function
    \argmin_{x} \lambda ||x||_1 + \mu /2 ||x||_2^2 + 0.5 ||x - input||_2^2

    Args:
      lambd: the :math:`\lambda` value on the ell_1 penalty term. Default: 0.5
      mu:    the :math:`\mu` value on the ell_2 penalty term. Default: 0.0

    Shape:
      - Input: :math:`(N, *)` where `*` means, any number of additional
        dimensions
      - Output: :math:`(N, *)`, same shape as the input

    """

    def __init__(self, lambd=0.5, mu=0.0):
        super(elasnet_prox, self).__init__()
        self.lambd = lambd
        self.scaling_mu = 1.0 / (1.0 + mu)
        pre_print("{}ResNet-DictBlock-elasnet_prox\t\tlambd-mu-scaling_mu:\t{}{}-{}-{}",    # 0.010000000000000002-0.0-1.0
                  (st1, _st1, self.lambd, mu, self.scaling_mu))

    def forward(self, input):
        running_print("{}ResNet-DictBlock-elasnet_prox\tlambd-scaling_mu:\t{}{}-{}", (st1, _st1, self.lambd, self.scaling_mu))
        return F.softshrink(input * self.scaling_mu, self.lambd * self.scaling_mu)

    def extra_repr(self):
        return '{} {}'.format(self.lambd, self.scaling_mu)


class DictBlock(nn.Module):
    # c = argmin_c lmbd * ||c||_1  +  mu/2 * ||c||_2^2 + 1 / 2 * ||x - weight (@conv) c||_2^2
    # in_channels ->n_channel, out_channels -> dict_size
    def __init__(self, n_channel, dict_size, mu=0.0, lmbd=0.0, n_dict=1, non_negative=True,  # model parameters
                 stride=1, kernel_size=3, padding=1, share_weight=True, square_noise=True,  # optional model parameters
                 n_steps=10, step_size_fixed=True, step_size=0.1, w_norm=True, padding_mode="constant", zsize=None):  # training parameters
        super(DictBlock, self).__init__()

        self.mu = mu
        self.lmbd = lmbd  # LAMBDA
        self.n_dict = n_dict
        self.stride = stride
        self.kernel_size = (kernel_size, kernel_size)
        self.padding = padding
        self.padding_mode = padding_mode
        assert self.padding_mode in ['constant', 'reflect', 'replicate', 'circular']
        self.groups = 1
        self.n_steps = n_steps
        self.conv_transpose_output_padding = 0 if (stride == 1 or stride == 2) else 1
        self.w_norm = w_norm
        self.non_negative = non_negative
        self.v_max = None
        self.v_max_error = 0.
        self.xsize = None
        self.zsize = zsize
        self.lmbd_ = None
        self.square_noise = square_noise

        self.it = 0
        self.c_pre = None
        self.c = None
        self.t = 0
        self.state = None

        # n_variables = 1 if share_weight else self.n_steps
        self.weight = nn.Parameter(torch.Tensor(dict_size, self.n_dict * n_channel, kernel_size, kernel_size))
        pre_print("{}ResNet-DictBlock\t\t\tweight size:\t\t{}{}", (st1, _st1, list(self.weight.size())))    # [64, 3, 3, 3]
        pre_print("{}ResNet-DictBlock\t\t\tn_steps:\t\t{}{}", (st1, _st1, self.n_steps))    # 2
        pre_print("{}ResNet-DictBlock\t\t\tstep_size:\t\t{}{}", (st1, _st1, step_size))     # 0.1
        pre_print("{}ResNet-DictBlock\t\t\tn_dict:\t\t\t{}{}", (st1, _st1, self.n_dict))    # 1

        with torch.no_grad():
            init.kaiming_uniform_(self.weight)

        # variables that are needed for ISTA/FISTA
        self.nonlinear = elasnet_prox(self.lmbd * step_size, self.mu * step_size)    # soft shrink

        self.register_buffer('step_size', torch.tensor(step_size, dtype=torch.float))

        # if torch.cuda.device_count() == 1:
        #     self.register_buffer('step_size', torch.tensor(step_size, dtype=torch.float))
        # elif torch.cuda.device_count() > 1:
        #     # if # of gpus larger than 1,
        #     self.step_size = step_size
        # else:
        #     raise NotImplementedError

        # if step_size_fixed:
        #     self.step_size = [step_size for _ in range(n_variables)]
        # else:
        #     self.step_size = nn.ParameterList(
        #         [nn.Parameter(torch.Tensor([step_size]))  # [math.sqrt(dict_size / n_channel)]))
        #          for _ in range(n_variables)])

    def fista_forward(self, x):
        running_print("{}\nResNet-DictBlock-fista_forward\tstate: {}:{}", (st1, self.state, _st1))
        running_print("{}\nResNet-DictBlock-fista_forward\tx:{}\t\t\t{}", (st1, _st1, list(x.size())))

        # self.c_error = []
        running_print("{}\nResNet-DictBlock-fista_forward\tstep {}:{}", (st1, self.it + 1, _st1))
        weight = self.weight
        step_size = self.step_size

        if self.state == 'train':
            if self.it == 0:
                for i in range(2):
                    weight = self.weight
                    step_size = self.step_size

                    if i == 0:
                        c_pre = 0.

                        c = step_size * F.conv2d(x.repeat(1, self.n_dict, 1, 1), weight, bias=None, stride=self.stride,
                                                padding=self.padding)
                        running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}", (st1, _st1, list(c.size())))

                        # print(f"c.device: {c.device}")
                        # print(self.nonlinear)
                        c = self.nonlinear(c)
                        running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}", (st1, _st1, list(c.size())))
                    elif i == 1:
                        c_pre = c.clone().detach()    # .to(device)!
                        # weight = self.normalize(weight)
                        xp = F.conv_transpose2d(c, weight, bias=None, stride=self.stride, padding=self.padding,
                                                output_padding=self.conv_transpose_output_padding)
                        running_print("{}ResNet-DictBlock-fista_forward\txp:{}\t\t\t{}", (st1, _st1, list(xp.size())))

                        r = x.repeat(1, self.n_dict, 1, 1) - xp
                        running_print("{}ResNet-DictBlock-fista_forward\tr:{}\t\t\t{}", (st1, _st1, list(r.size())))

                        if self.square_noise:
                            gra = F.conv2d(r, weight, bias=None, stride=self.stride, padding=self.padding)
                        else:
                            w = r.view(r.size(0), -1)
                            normw = w.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12).expand_as(w).detach()
                            w = (w / normw).view(r.size())

                            gra = F.conv2d(w, weight, bias=None, stride=self.stride, padding=self.padding) * 0.5
                        running_print("{}ResNet-DictBlock-fista_forward\tgra:{}\t\t\t{}", (st1, _st1, list(gra.size())))

                        c = c + step_size * gra
                        c = self.nonlinear(c)
                        t = (math.sqrt(5.0) + 1.0) / 2.0
                        running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}\n", (st1, _st1, list(c.size())))

                        if self.non_negative:
                            c = F.relu(c)
                        self.c_pre = c_pre
                        self.c = c.clone().detach()
                        self.t = t

                    # self.c_error.append(torch.sum((c) ** 2) / c.shape[0])

                self.it += 2
            else:
                c_pre = self.c_pre
                t_pre = self.t
                c = self.c
                t = (math.sqrt(1.0 + 4.0 * t_pre * t_pre) + 1) / 2.0
                a = (t_pre + t - 1.0) / t * c + (1.0 - t_pre) / t * c_pre
                c_pre = c.clone().detach()    # .to(device)
                running_print("{}ResNet-DictBlock-fista_forward\ta:{}\t\t\t{}", (st1, _st1, list(a.size())))
                # weight = self.normalize(weight)
                xp = F.conv_transpose2d(c, weight, bias=None, stride=self.stride, padding=self.padding,
                                        output_padding=self.conv_transpose_output_padding)
                running_print("{}ResNet-DictBlock-fista_forward\txp:{}\t\t\t{}", (st1, _st1, list(xp.size())))

                r = x.repeat(1, self.n_dict, 1, 1) - xp
                running_print("{}ResNet-DictBlock-fista_forward\tr:{}\t\t\t{}", (st1, _st1, list(r.size())))

                if self.square_noise:
                    gra = F.conv2d(r, weight, bias=None, stride=self.stride, padding=self.padding)
                else:

                    w = r.view(r.size(0), -1)
                    normw = w.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12).expand_as(w).detach()
                    w = (w / normw).view(r.size())

                    gra = F.conv2d(w, weight, bias=None, stride=self.stride, padding=self.padding) * 0.5
                running_print("{}ResNet-DictBlock-fista_forward\tgra:{}\t\t\t{}", (st1, _st1, list(gra.size())))

                c = a + step_size * gra
                c = self.nonlinear(c)
                running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}\n", (st1, _st1, list(c.size())))

                if self.non_negative:
                    c = F.relu(c)
                self.c_pre = c_pre
                self.c = c.clone().detach()    # .to(device)
                self.t = t

                # self.c_error.append(torch.sum((c) ** 2) / c.shape[0])

                self.it += 1

                if self.it == args.n_steps:
                    self.reset_dictblock_state(state='train')
        elif self.state == 'eval':
            self.n_steps = args.n_steps
            for i in range(self.n_steps):
                running_print("{}\nResNet-DictBlock-fista_forward\tstep {}/{}:{}", (st1, i + 1, self.n_steps, _st1))
                weight = self.weight
                step_size = self.step_size

                if i == 0:
                    c_pre = 0.

                    c = step_size * F.conv2d(x.repeat(1, self.n_dict, 1, 1), weight, bias=None, stride=self.stride,
                                            padding=self.padding)
                    running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}", (st1, _st1, list(c.size())))

                    # print(f"c.device: {c.device}")
                    # print(self.nonlinear)
                    c = self.nonlinear(c)
                    running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}", (st1, _st1, list(c.size())))
                elif i == 1:
                    c_pre = c.clone().detach()    # .to(device)!
                    # weight = self.normalize(weight)
                    xp = F.conv_transpose2d(c, weight, bias=None, stride=self.stride, padding=self.padding,
                                            output_padding=self.conv_transpose_output_padding)
                    running_print("{}ResNet-DictBlock-fista_forward\txp:{}\t\t\t{}", (st1, _st1, list(xp.size())))

                    r = x.repeat(1, self.n_dict, 1, 1) - xp
                    running_print("{}ResNet-DictBlock-fista_forward\tr:{}\t\t\t{}", (st1, _st1, list(r.size())))

                    if self.square_noise:
                        gra = F.conv2d(r, weight, bias=None, stride=self.stride, padding=self.padding)
                    else:
                        w = r.view(r.size(0), -1)
                        normw = w.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12).expand_as(w).detach()
                        w = (w / normw).view(r.size())

                        gra = F.conv2d(w, weight, bias=None, stride=self.stride, padding=self.padding) * 0.5
                    running_print("{}ResNet-DictBlock-fista_forward\tgra:{}\t\t\t{}", (st1, _st1, list(gra.size())))

                    c = c + step_size * gra
                    c = self.nonlinear(c)
                    t = (math.sqrt(5.0) + 1.0) / 2.0
                    running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}\n", (st1, _st1, list(c.size())))

                    if self.non_negative:
                        c = F.relu(c)
                    self.c_pre = c_pre
                    self.c = c.clone().detach()
                    self.t = t
                else:
                    c_pre = self.c_pre
                    t_pre = self.t
                    c = self.c
                    t = (math.sqrt(1.0 + 4.0 * t_pre * t_pre) + 1) / 2.0
                    a = (t_pre + t - 1.0) / t * c + (1.0 - t_pre) / t * c_pre
                    c_pre = c.clone().detach()    # .to(device)
                    running_print("{}ResNet-DictBlock-fista_forward\ta:{}\t\t\t{}", (st1, _st1, list(a.size())))
                    # weight = self.normalize(weight)
                    xp = F.conv_transpose2d(c, weight, bias=None, stride=self.stride, padding=self.padding,
                                            output_padding=self.conv_transpose_output_padding)
                    running_print("{}ResNet-DictBlock-fista_forward\txp:{}\t\t\t{}", (st1, _st1, list(xp.size())))

                    r = x.repeat(1, self.n_dict, 1, 1) - xp
                    running_print("{}ResNet-DictBlock-fista_forward\tr:{}\t\t\t{}", (st1, _st1, list(r.size())))

                    if self.square_noise:
                        gra = F.conv2d(r, weight, bias=None, stride=self.stride, padding=self.padding)
                    else:

                        w = r.view(r.size(0), -1)
                        normw = w.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12).expand_as(w).detach()
                        w = (w / normw).view(r.size())

                        gra = F.conv2d(w, weight, bias=None, stride=self.stride, padding=self.padding) * 0.5
                    running_print("{}ResNet-DictBlock-fista_forward\tgra:{}\t\t\t{}", (st1, _st1, list(gra.size())))

                    c = a + step_size * gra
                    c = self.nonlinear(c)
                    running_print("{}ResNet-DictBlock-fista_forward\tc:{}\t\t\t{}\n", (st1, _st1, list(c.size())))

                    if self.non_negative:
                        c = F.relu(c)
                    self.c_pre = c_pre
                    self.c = c.clone().detach()    # .to(device)
                    self.t = t

            # self.c_error.append(torch.sum((c) ** 2) / c.shape[0])
        else:
            print('state {} is not train or eval!'.format(self.state))
            exit()

        return c, weight

    def forward(self, x):
        running_print("{}ResNet-DictBlock\t\tx:{}\t\t\t{}", (st1, _st1, list(x.size())))
        running_print("{}ResNet-DictBlock\t\tstep_size:{}\t\t{}", (st1, _st1, self.step_size))

        if self.xsize is None:
            self.xsize = (x.size(-3), x.size(-2), x.size(-1))
            running_print("{}ResNet-DictBlock\t\txsize:{}\t\t\t{}", (st1, _st1, self.xsize))
        else:
            assert self.xsize[-3] == x.size(-3) and self.xsize[-2] == x.size(-2) and self.xsize[-1] == x.size(-1)

        if self.w_norm:
            self.normalize_weight()    # why normalize weight?

        # self.c_error = []
        c, weight = self.fista_forward(x)
        running_print("{}ResNet-DictBlock\t\tc:{}\t\t\t{}", (st1, _st1, list(c.size())))

        # Compute loss
        xp = F.conv_transpose2d(c, weight, bias=None, stride=self.stride, padding=self.padding,
                                output_padding=self.conv_transpose_output_padding)
        running_print("{}ResNet-DictBlock\t\txp:{}\t\t\t{}", (st1, _st1, list(xp.size())))
        r = x.repeat(1, self.n_dict, 1, 1) - xp
        r_loss = torch.sum(torch.pow(r, 2)) / self.n_dict
        c_loss = self.lmbd * torch.sum(torch.abs(c)) + self.mu / 2. * torch.sum(torch.pow(c, 2))    # Equ.(4)?
        running_print("{}ResNet-DictBlock\t\tr_loss-c_loss:{}\t\t{}-{}", (st1, _st1, r_loss, c_loss))

        if self.zsize is None:
            self.zsize = (c.size(-3), c.size(-2), c.size(-1))
            running_print("{}ResNet-DictBlock\t\tzsize:{}\t\t\t{}", (st1, _st1, self.zsize))
            # print(self.zsize)
        else:
            assert self.zsize[-3] == c.size(-3) and self.zsize[-2] == c.size(-2) and self.zsize[-1] == c.size(-1)

        if self.lmbd_ is None and config.MODEL.ADAPTIVELAMBDA:
            self.lmbd_ = self.lmbd * self.xsize[-3] * self.xsize[-2] * self.xsize[-1] / (self.zsize[-3] * self.zsize[-2] * self.zsize[-1])
            self.lmbd = self.lmbd_
            print("======")
            print("xsize", self.xsize)
            print("zsize", self.zsize)
            print("new lmbd: ", self.lmbd)

        return c, (r_loss, c_loss)

    def update_stepsize(self):
        step_size = args.step_rate / self.power_iteration(self.weight)
        self.step_size = self.step_size * 0. + step_size
        running_print("{}ResNet-DictBlock\t\tstep_size:{}\t\t{}", (st1, _st1, step_size))
        # self.step_size.fill_(step_size)
        self.nonlinear.lambd = self.lmbd * step_size
        self.nonlinear.scaling_mu = 1.0 / (1.0 + self.mu * step_size)

    def reset_dictblock_state(self, it=0, c_pre=None, c=None, t=0, state=None):
        self.it = it
        self.c_pre = c_pre
        self.c = c
        self.t = t
        self.state = state

    def normalize_weight(self):
        with torch.no_grad():
            w = self.weight.view(self.weight.size(0), -1)
            normw = w.norm(p=2, dim=1, keepdim=True).clamp_min(1e-12).expand_as(w)
            w = (w / normw).view(self.weight.size())
            self.weight.data = w.data

    def power_iteration(self, weight):

        max_iteration = 50
        v_max_error = 1.0e5
        tol = 1.0e-5
        k = 0

        with torch.no_grad():
            if self.v_max is None:
                c = weight.shape[0]
                v = torch.randn(size=(1, c, self.zsize[-2], self.zsize[-1])).to(weight.device)
            else:
                v = self.v_max.clone()

            while k < max_iteration and v_max_error > tol:

                tmp = F.conv_transpose2d(
                    v, weight, bias=None, stride=self.stride, padding=self.padding,
                    output_padding=self.conv_transpose_output_padding
                )
                v_ = F.conv2d(tmp, weight, bias=None, stride=self.stride, padding=self.padding)
                v_ = F.normalize(v_.view(-1), dim=0, p=2).view(v.size())
                v_max_error = torch.sum((v_ - v) ** 2)
                k += 1
                v = v_

            v_max = v.clone()
            Dv_max = F.conv_transpose2d(
                v_max, weight, bias=None, stride=self.stride, padding=self.padding,
                output_padding=self.conv_transpose_output_padding
            )  # Dv

            lambda_max = torch.sum(Dv_max ** 2).item()  # vTDTDv / vTv, ignore the vTv since vTv = 1

        self.v_max = v_max
        return lambda_max
