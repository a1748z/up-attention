import torch
from torch import nn
import torch.nn.functional as F

from einops import rearrange, repeat
from einops.layers.torch import Rearrange

from timm.models.registry import register_model
from timm.models.layers import trunc_normal_

from rich import print
from util_scripts.print_info import pre_print, running_print, st1, _st1, st2, _st2

# helpers

def pair(t):
    return t if isinstance(t, tuple) else (t, t)

# classes

class LayerNorm(nn.Module):
    r""" LayerNorm that supports two data formats: channels_last (default) or channels_first. 
    The ordering of the dimensions in the inputs. channels_last corresponds to inputs with 
    shape (batch_size, height, width, channels) while channels_first corresponds to inputs 
    with shape (batch_size, channels, height, width).
    """
    def __init__(self, normalized_shape, eps=1e-6, data_format="channels_last"):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps
        self.data_format = data_format
        if self.data_format not in ["channels_last", "channels_first"]:
            raise NotImplementedError 
        self.normalized_shape = (normalized_shape, )
    
    def forward(self, x):
        if self.data_format == "channels_last":
            return F.layer_norm(x, self.normalized_shape, self.weight, self.bias, self.eps)
        elif self.data_format == "channels_first":
            u = x.mean(1, keepdim=True)
            s = (x - u).pow(2).mean(1, keepdim=True)
            x = (x - u) / torch.sqrt(s + self.eps)
            x = self.weight[:, None, None] * x + self.bias[:, None, None]
            return x

'''
class FeedForward(nn.Module):
    def __init__(self, dim, hidden_dim, dropout = 0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)
'''

class GEGLU(nn.Module):
    def forward(self, x):
        x, gates = x.chunk(2, dim=-1)
        return x * F.gelu(gates)

class FeedForward(nn.Module):
    def __init__(self, dim, dim_out=None, mult=4, dropout=0.):
        super().__init__()
        self.net = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, dim * mult * 2),
            GEGLU(),
            nn.Dropout(dropout),
            nn.Linear(dim * mult, dim if dim_out is None else dim_out),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        running_print("{}FeedForward - x:{}\t\t\t\t{}", (st1, _st1, list(x.size())))
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads = 8, dim_head = 64, dropout = 0.):
        super().__init__()
        inner_dim = dim_head *  heads
        project_out = not (heads == 1 and dim_head == dim)

        self.dim = dim
        self.dim_head = dim_head
        self.heads = heads
        self.inner_dim = inner_dim
        self.scale = dim_head ** -0.5

        self.norm = nn.LayerNorm(dim)

        self.attend = nn.Softmax(dim = -1)
        self.dropout = nn.Dropout(dropout)

        self.to_qkv = nn.Linear(dim, inner_dim * 3, bias = False)

        self.to_out = nn.Sequential(
            nn.Linear(inner_dim, dim),
            nn.Dropout(dropout)
        ) if project_out else nn.Identity()

    def forward(self, x):
        running_print("{}Attention - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))
        running_print("{}Attention: dim-inner_dim-heads-dim_head:\t{}-{}-{}-{}{}",
                      (st2, self.dim, self.inner_dim, self.heads, self.dim_head, _st2))

        x = self.norm(x)

        qkv = self.to_qkv(x).chunk(3, dim = -1)
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = self.heads), qkv)
        running_print("{}Attention - q-k-v:{}\t\t\t\t{}-{}-{}", (st1, _st1, list(q.size()), list(k.size()), list(v.size())))

        dots = torch.matmul(q, k.transpose(-1, -2)) * self.scale
        running_print("{}Attention - dots:{}\t\t\t\t{}", (st1, _st1, list(dots.size())))

        attn = self.attend(dots)
        attn = self.dropout(attn)
        running_print("{}Attention - attn:{}\t\t\t\t{}", (st1, _st1, list(attn.size())))

        out = torch.matmul(attn, v)
        running_print("{}Attention - out:{}\t\t\t\t{}", (st1, _st1, list(out.size())))

        out = rearrange(out, 'b h n d -> b n (h d)')
        running_print("{}Attention - out:{}\t\t\t\t{}", (st1, _st1, list(out.size())))

        return self.to_out(out)

class Transformer(nn.Module):
    def __init__(self, dim, depth, heads, dim_head, dropout = 0.):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Attention(dim, heads = heads, dim_head = dim_head, dropout = dropout),
                FeedForward(dim, dropout = dropout)
            ]))

    def forward(self, x):
        i = 1
        for attn, ff in self.layers:
            running_print("{}\nTransformer - depth {}:{}", (st1, i, _st1))
            x = attn(x) + x
            x = ff(x) + x
            i = i + 1

        return self.norm(x)

class ViT(nn.Module):
    def __init__(self, *, image_size=32, patch_size=1, num_classes=1000,
                 dim=512, depth=12, heads=12, pool = 'cls',
                 channels = 3, dim_head = 64, dropout = 0., emb_dropout = 0.):
        super().__init__()
        image_height, image_width = pair(image_size)
        patch_height, patch_width = pair(patch_size)

        assert image_height % patch_height == 0 and image_width % patch_width == 0, 'Image dimensions must be divisible by the patch size.'

        num_patches = (image_height // patch_height) * (image_width // patch_width)
        patch_dim = channels * patch_height * patch_width
        assert pool in {'cls', 'mean'}, 'pool type must be either cls (cls token) or mean (mean pooling)'

        pre_print("{}ViT - num classes:{} {}", (st1, _st1, num_classes))
        pre_print("{}ViT - image size - patches - patch dim:{}\t{}-{}-{}", (st1, _st1, image_size, num_patches, patch_dim))

        self.to_patch_embedding = nn.Sequential(
            Rearrange('b c h w -> b (h w) c'),
            nn.LayerNorm(dim),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )

        self.pos_embedding = nn.Parameter(torch.randn(1, num_patches + 1, dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        self.transformer = Transformer(dim, depth, heads, dim_head, dropout)

        self.pool = pool
        self.to_latent = nn.Identity()

        self.mlp_head = nn.Linear(dim, num_classes)

        self.stem = nn.Sequential(nn.Conv2d(channels, dim, kernel_size=5, padding=2, stride=1),
                                  LayerNorm(dim, eps=1e-6, data_format="channels_first"))
        
        self.downsample = nn.Sequential(nn.Conv2d(dim, dim, kernel_size=2, stride=2),
                                        LayerNorm(dim, eps=1e-6, data_format="channels_first"),)
        
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        else:
            # print("{} is not the instance of nn ...".format(type(m)))
            pass

    def forward(self, img):
        running_print("\n{}ViT - img:{}\t\t\t\t\t{}", (st1, _st1, list(img.size())))

        x = self.stem(img)
        up1 = x
        running_print("{}ViT - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))    # [8, 192, 32, 32]

        x = self.downsample(x)
        running_print("{}ViT - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))    # [8, 192, 16, 16]

        x = self.to_patch_embedding(x)
        b, n, _ = x.shape
        running_print("{}ViT - x:{}\t\t\t\t\t{}", (st1, _st1, list(x.size())))    # [8, 256, 192]

        cls_tokens = repeat(self.cls_token, '1 1 d -> b 1 d', b = b)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        x = self.transformer(x)
        running_print("{}ViT - after transformer x:{}\t\t\t{}", (st1, _st1, list(x.size())))

        x = x.mean(dim = 1) if self.pool == 'mean' else x[:, 0]
        running_print("{}ViT - after mean x:{}\t\t\t\t{}", (st1, _st1, list(x.size())))

        x = self.to_latent(x)
        x = self.mlp_head(x)
        running_print("{}ViT - after head x:{}\t\t\t\t{}", (st1, _st1, list(x.size())))
        running_print("{}{}{}\n", (st1, '-' * 100, _st1))

        return x

@register_model
def vit_tiny(pretrained=False, pretrained_cfg=None, pretrained_cfg_overlay=None, **kwargs) -> ViT:
    """ ViT-Tiny (Vit-Ti/16)
    """

    model_args = dict(patch_size=2, dim=192, depth=6, heads=6, dim_head=32)
    model = ViT(dropout = 0.1, emb_dropout = 0.1, **dict(model_args, **kwargs))

    return model

'''

'''