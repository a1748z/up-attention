from opts import get_args_parser
from rich import print
st1 = "[bold #F00056]"
_st1 = "[/bold #F00056]"
st2 = "[bold #21FF06]"
_st2 = "[/bold #21FF06]"

parser = get_args_parser()
args = parser.parse_args()


def running_print(info, t=None):
    if args.running_print is False:
        return

    if t is not None:
        print(info.format(*t))
    else:
        print(info)


def pre_print(info, t=None, pr=True):
    if args.pre_print is False or pr is False:
        return

    if t is not None:
        print(info.format(*t))
    else:
        print(info)

def get_lr(optimizer):
    # print("optimizer: {}".format(optimizer))
    lrs = []
    for param_group in optimizer.param_groups:
        if param_group['lr'] is not None:
            lr = float(param_group['lr'])
            lrs.append(lr)

    return lrs

def get_fine_tuning_parameters(model):
    parameters = []
    for k, v in model.named_parameters():
        lr_up = args.attention_lr
        '''
           ('stages.2.0.norm' in k) or ('stages.2.0.pwconv1' in k) or \
           ('stages.2.26.norm' in k) or ('stages.2.26.pwconv1' in k) or \
           ('stages.3.0.norm' in k) or ('stages.3.0.pwconv1' in k) or \
           ('stages.3.2.norm' in k) or ('stages.3.2.pwconv1' in k) or \
           ('norm.weight' == k) or ('norm.bias' == k) or 
        '''
        if ('attention' in k) or ('stages.3' in k) or ('head' in k):
            pre_print("{}params\t{}\t\tuse lr {}{}", (st1, k, lr_up, _st1))
            parameters.append({'params': v, 'lr': lr_up})
        else:
            pre_print("{}params\t{}\t\tuse default lr {}.{}", (st1, k, args.lr, _st1))
            parameters.append({'params': v, 'lr': args.lr})

    return parameters

def get_fine_tuning_lr(name):
    lr_up = args.attention_lr
    '''
       ('stages.2.0.norm' in name) or ('stages.2.0.pwconv1' in name) or \
       ('stages.2.26.norm' in name) or ('stages.2.26.pwconv1' in name) or \
       ('stages.3.0.norm' in name) or ('stages.3.0.pwconv1' in name) or \
       ('stages.3.2.norm' in name) or ('stages.3.2.pwconv1' in name) or \
       ('norm.weight' == name) or ('norm.bias' == name) or 
    '''
    if ('attention' in name) or ('stages.3' in name) or ('head' in name):
        pre_print("{}params\t{}\t\tuse finetune lr\t{}{}", (st1, name, lr_up, _st1))
        lr = lr_up
    else:
        pre_print("{}params\t{}\t\tuse default lr\t{}.{}", (st1, name, args.lr, _st1))
        lr = args.lr

    return lr

'''
# i added
# 0.0001, 0.0001, 0.0001, 0.001, 0.001 -- save5  -- 0.617
# 0.0001, 0.0001, 0.001,  0.001, 0.001 -- save5  -- 0.632

# 0.0001, 0.001,  0.001,  0.001, 0.001 -- save10 -- 0.637
# 0.0001, 0.0001, 0.001,  0.001, 0.001 -- save10 -- 0.645
# 0.0001, 0.0001, 0.0001, 0.001, 0.001 -- save10 -- 0.633

# 0.001,  0.001,  0.001,  0.001, 0.01  -- save15 -- 0.657
# 0.001,  0.001,  0.001,  0.001, 0.001 -- save15 -- 0.652
# 0.0001, 0.001,  0.001,  0.001, 0.001 -- save15 -- 0.655
# 0.0001, 0.0001, 0.001,  0.001, 0.001 -- save15 -- 0.645

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save20 -- 0.656
# 0.001,   0.001,  0.001,  0.001, 0.001  -- save20 -- 0.654
# 0.0001,  0.001,  0.001,  0.001, 0.01   -- save20 -- 0.648
# 0.0001,  0.001,  0.001,  0.001, 0.001  -- save20 -- 0.649

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save25 -- 0.664
# 0.001,   0.001,  0.001,  0.001, 0.001   -- save25 -- 0.644

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save30 -- 0.670 -- bs128 -- no class token
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save30 -- 0.671 -- bs128 -- including class token
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save30 -- 0.671 -- bs64  -- including class

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save35 -- 0.676 -- bs128 -- including class token -- patience 30

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save40 -- 0.677 -- bs128 -- including class token -- patience 20
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save40 -- 0.672 -- bs128 -- including class token -- patience 30
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save40 -- 0.668 -- bs128 -- including class token -- patience 40

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save45 -- 0.695 -- bs128 -- including class token -- patience 3
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save45 -- 0.689 -- bs128 -- including class token -- patience 5
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save45 -- 0.681 -- bs128 -- including class token -- patience 10
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save45 -- 0.679 -- bs128 -- including class token -- patience 20
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save45 -- 0.667 -- bs128 -- including class token -- patience 30

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save50 -- 0.691 -- bs128 -- including class token -- patience 1
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save50 -- 0.693 -- bs128 -- including class token -- patience 2
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save50 -- 0.689 -- bs128 -- including class token -- patience 3
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save50 -- 0.688 -- bs128 -- including class token -- patience 5

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.685 -- bs128 -- including class token -- patience 1
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.696 -- bs128 -- including class token -- patience 2 @ 35
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.687 -- bs128 -- including class token -- patience 3 @ 21
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.691 -- bs128 -- including class token -- patience 5 @ 41
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.688 -- bs128 -- including class token -- patience10 @ 92

# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.689 -- bs128 -- including class token -- patience 2 @ 49
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.702 -- bs128 -- including class token -- patience 3 @ 24
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.696 -- bs128 -- including class token -- patience 5 @ 47
# 0.001,   0.001,  0.001,  0.001, 0.01   -- save55 -- 0.691 -- bs128 -- including class token -- patience 10@ 40
'''
